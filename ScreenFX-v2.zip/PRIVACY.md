# ScreenFX Privacy Policy

_Last updated: October 17, 2026_

ScreenFX does not collect, store, or share any personal data.

- The app has no accounts, no analytics, no ads, and no internet access.
- Touches are only used, on your device and in the moment, to draw animations where you touch. They are never recorded, saved, or sent anywhere.
- Your settings (theme, border and effect choices) are stored only on your device and are removed when you uninstall the app.

**Permissions**
- *Display over other apps*: needed to draw the border and effects on top of other apps.
- *Accessibility (optional "tap helper")*: only used, if you switch it on, to pass your own taps, holds and swipes through to the app underneath while Play mode is on. It does not read screen content and nothing is stored or sent.
- *Notifications / foreground service*: shows a persistent notification while the overlay is running, so you can switch modes or stop it at any time.

Questions: contact the developer through the email address on the app's Google Play listing.
