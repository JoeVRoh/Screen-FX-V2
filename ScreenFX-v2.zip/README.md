# ScreenFX

An Android app that puts an animated border and touch effects over your whole screen.

- **Borders:** Glow pulse, Rainbow chase, Marquee lights, Sparkle, Flames, Lightning, Gas fog (thickness, speed, opacity, corner rounding)
- **Effects for tap / hold / swipe:** Pop (confetti), Cloud (hold = storm with rain and lightning), Fireball (swipe to throw, hold for a meteor), Bomb (tap drops one, swipe throws it, hold plants it), Shot (bullet holes with transparent glass cracks; hold = shotgun, swipe = spray), Sparkles, Ripple, Gas (fart cloud), Lightning, Laser, Paint splat, Hearts, Fireworks
- **Sound effects** for every effect, with an on/off switch and volume (all sounds are synthesized by `tools/make_sounds.py`)
- **9 color themes** (including Toxic) and **12 templates**, including Fart Attack, Celebration, Sci-Fi, Art Attack and Love
- Live preview pad inside the app

## How the two modes work

Android lets an overlay either pass touches through to the apps underneath, or catch them, but never both. So:

- **Normal use:** the border animates on top of everything and your phone works as usual.
- **Play mode:** tap the floating button (or the notification) and taps, holds and swipes anywhere make effects. Tap the button again to get your phone back. Long-press the button to open settings.
- **Play mode with "Taps still work":** effects appear *and* each gesture is passed on to the app underneath. This needs the optional ScreenFX tap helper (an Accessibility service) switched on.

### Turning on the tap helper
1. In ScreenFX, switch on **Taps still work in Play mode**, then tap **Turn on tap helper → Continue**.
2. In Accessibility settings, open **ScreenFX tap helper** (sometimes under **Downloaded apps** or **Installed apps**) and switch it on.
3. If the switch is greyed out: this is Android 13+ protecting apps installed outside the Play Store. Go back to ScreenFX, tap **Open App info**, tap the **⋮** menu (top right), choose **Allow restricted settings**, confirm, and try step 2 again.

Taps and long-presses behave normally. Swipes and scrolls are replayed just after you lift your finger. Two-finger gestures (pinch-zoom) aren't passed on.

---

## Part 1: Get the test app on your phone (no computer needed)

You'll use GitHub's free cloud computers to build the app.

1. Create a free account at **github.com** and sign in.
2. Tap **+ → New repository**. Name it `ScreenFX`, choose **Private**, tap **Create repository**.
3. Tap **uploading an existing file** (or **Add file → Upload files**) and upload **ScreenFX.zip** exactly as you received it. Commit.
4. Tap **Add file → Create new file**. For the name type exactly:
   `.github/workflows/build.yml`
   Paste the contents of `.github/workflows/build.yml` from inside the zip (also shown at the bottom of this guide). Commit.
   *(On a computer you can skip steps 3–4 by unzipping and uploading all the files and folders instead.)*
5. Open the **Actions** tab. A "Build ScreenFX" run starts automatically. Wait about 5 minutes for the green check.
6. Open the finished run, scroll to **Artifacts**, and download **ScreenFX-test-apk**. It downloads as a .zip; open it in your Files app to get `app-debug.apk`.
7. Tap the APK to install. Android will ask you to allow installs from your browser or Files app; allow it.
8. Open ScreenFX → **Allow "Display over other apps"** → switch ScreenFX on → come back → **Start overlay**.

> Each test build is signed with a new temporary key, so to install a newer test build, uninstall the old one first.

## Part 2: Publish on Google Play

1. **Pick your permanent app ID.** In `app/build.gradle.kts`, change `applicationId = "com.screenfx.overlay"` to something unique, e.g. `com.yourname.screenfx`. It can never change after the first upload. (If you uploaded the zip, edit this file inside the zip before uploading, or tell me your preferred ID and I'll repackage it.)
2. **Add the signing secrets.** In your GitHub repo: **Settings → Secrets and variables → Actions → New repository secret**. Add the four secrets listed in `SECRETS.txt` from the signing kit. Never put the signing kit in the repository.
3. **Rebuild.** Actions tab → **Build ScreenFX** → **Run workflow**. When finished, download the **ScreenFX-google-play** artifact; it contains `app-release.aab` (for Play) and a signed `app-release.apk`.
4. **Create a Play developer account** at play.google.com/console (one-time US$25 and identity verification).
5. **Create the app** in Play Console, then go to **Testing → Internal testing**, create a release, and upload `app-release.aab`. Add yourself as a tester and install from the opt-in link. (Uninstall the test APK first; the signatures differ.)
6. **Fill in the required pages:**
   - Store listing: use `store/play-icon-512.png` and `store/feature-graphic-1024x500.png`, plus 2+ phone screenshots.
   - Privacy policy URL: host `PRIVACY.md` (for example as a public GitHub Gist or Google Sites page) and paste its link.
   - Data safety: the app collects and shares no data.
   - App content: no ads; content rating questionnaire; target audience.
   - Foreground service declaration: type **Special use**. Explain: "Keeps a user-enabled decorative overlay (animated screen border and touch effects) visible over other apps while the user has it switched on. A persistent notification lets the user turn it off."
   - The app uses the "Display over other apps" permission because drawing over other apps is its core feature.
   - **Accessibility (tap helper):** Google Play reviews apps that use the Accessibility API closely and may reject uses that aren't for people with disabilities. You must fill in the Accessibility declaration in Play Console (the app already shows a disclosure before sending people to the setting). If Play rejects it, remove the `TapHelperService` block from `AndroidManifest.xml` and rebuild; everything else keeps working, and the test APK can keep the feature.
7. **Going public:** new personal developer accounts must run a closed test with at least 12 testers for 14 days before Play unlocks production. Organization accounts skip this.

## Building on a computer instead (optional)

Open the folder in Android Studio and press Run, or from a terminal: `./gradlew assembleDebug`.

## Good to know

- The status bar, navigation bar and keyboard always draw above overlays, so the border sits just under them.
- Android hides all overlays on some system screens (permission pages, lock screen), by design.
- An animated border redraws continuously, which uses some battery. Choose "Off" for the border if you only want touch effects.
- On Android 12+, the overlay is drawn at about 80% opacity in Normal use; that's Android's rule for letting touches pass through.

## Workflow file (for step 4 of Part 1)

```yaml
name: Build ScreenFX

on:
  push:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    env:
      KEYSTORE_BASE64: ${{ secrets.KEYSTORE_BASE64 }}
      SIGNING_STORE_PASSWORD: ${{ secrets.SIGNING_STORE_PASSWORD }}
      SIGNING_KEY_ALIAS: ${{ secrets.SIGNING_KEY_ALIAS }}
      SIGNING_KEY_PASSWORD: ${{ secrets.SIGNING_KEY_PASSWORD }}
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Unpack the newest project zip
        run: |
          ZIP=$(git log -1 --format= --name-only --diff-filter=AM -- '*.zip' | head -n 1)
          echo "Using: $ZIP"
          if [ -n "$ZIP" ]; then unzip -o -q "$ZIP"; fi

      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: "17"

      - uses: gradle/actions/setup-gradle@v4

      - name: Build test APK
        run: bash ./gradlew assembleDebug --stacktrace

      - uses: actions/upload-artifact@v4
        with:
          name: ScreenFX-test-apk
          path: app/build/outputs/apk/debug/app-debug.apk

      - name: Build signed Play bundle
        if: env.KEYSTORE_BASE64 != ''
        run: |
          echo "$KEYSTORE_BASE64" | base64 -d > "$RUNNER_TEMP/upload.jks"
          export SIGNING_KEYSTORE_PATH="$RUNNER_TEMP/upload.jks"
          bash ./gradlew bundleRelease assembleRelease --stacktrace

      - uses: actions/upload-artifact@v4
        if: hashFiles('app/build/outputs/bundle/release/app-release.aab') != ''
        with:
          name: ScreenFX-google-play
          path: |
            app/build/outputs/bundle/release/app-release.aab
            app/build/outputs/apk/release/app-release.apk
```
