package com.screenfx.overlay;

final class Particle {
    static final int DOT = 0, CIRCLE = 1, CONFETTI = 2, SPARK = 3, STAR = 4, SHARD = 5, SMOKE = 6, FLAME = 7, HEART = 8;
    int kind, color, color2;
    float x, y, vx, vy, size, grow, gravity, drag, rot, vrot, age, life, phase, baseAlpha = 1f;
    boolean add;
}
