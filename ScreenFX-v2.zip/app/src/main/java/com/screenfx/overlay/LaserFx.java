package com.screenfx.overlay;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

import java.util.Random;

/** A laser beam from a source point to a target, or sweeping along a swipe path, burning a trail. */
final class LaserFx extends Fx {
    final float sx, sy, scale;
    final float[] path;
    final int n, color;
    final boolean crack;
    final ParticleFx sparks;
    private float cx, cy;
    private final Path burn = new Path();
    private boolean started;

    LaserFx(ParticleFx sparks, float sx, float sy, float[] path, int n, int color, float scale, float life, boolean crack) {
        this.sparks = sparks;
        this.sx = sx;
        this.sy = sy;
        this.path = path;
        this.n = n;
        this.color = color;
        this.scale = scale;
        this.life = life;
        this.crack = crack;
        sparks.keepAlive = true;
        cx = path[0];
        cy = path[1];
    }

    @Override
    boolean update(FxView w, float dt) {
        float dp = w.dp;
        Random r = w.rnd;
        if (n > 1) {
            float t = Math.min(1, age / (life * 0.85f)) * (n - 1);
            int i = Math.min(n - 2, (int) t);
            float f = t - i;
            cx = path[2 * i] + (path[2 * i + 2] - path[2 * i]) * f;
            cy = path[2 * i + 1] + (path[2 * i + 3] - path[2 * i + 1]) * f;
            if (!started) burn.moveTo(cx, cy);
            else burn.lineTo(cx, cy);
            started = true;
        }
        for (int k = 0; k < 3; k++) {
            float a = r.nextFloat() * Gfx.TAU, sp = (150 + r.nextFloat() * 400) * dp;
            Particle p = sparks.add(Particle.SPARK, cx, cy, cos(a) * sp, sin(a) * sp, 0.2f + r.nextFloat() * 0.25f,
                    2 * dp, k == 0 ? 0xFFFFFFFF : color);
            p.gravity = 700 * dp;
        }
        if (age >= life) {
            sparks.keepAlive = false;
            if (n > 1) w.addDecal(new BurnFx(burn, w.cfg.crackSeconds));
            else w.addDecal(CrackFx.scorch(w, cx, cy, 20 * dp * scale));
            if (crack) w.addDecal(CrackFx.glass(w, cx, cy, 110 * dp * scale, false));
            return false;
        }
        return true;
    }

    @Override
    void draw(Canvas c, FxView w) {
        float dp = w.dp * scale;
        float fl = 0.8f + 0.2f * w.rnd.nextFloat();
        Paint s = Gfx.stroke;
        if (started) {
            s.setColor(0xFFFF6E40);
            s.setAlpha(200);
            s.setStrokeWidth(3.5f * w.dp);
            c.drawPath(burn, s);
        }
        s.setColor(color);
        s.setAlpha(Gfx.alpha(0.2f * fl));
        s.setStrokeWidth(18 * dp);
        c.drawLine(sx, sy, cx, cy, s);
        s.setAlpha(Gfx.alpha(0.5f * fl));
        s.setStrokeWidth(7 * dp);
        c.drawLine(sx, sy, cx, cy, s);
        s.setColor(0xFFFFFFFF);
        s.setAlpha(255);
        s.setStrokeWidth(2.4f * dp);
        c.drawLine(sx, sy, cx, cy, s);
        Gfx.dot(c, cx, cy, 26 * dp * fl, color, 220, true);
        Gfx.dot(c, cx, cy, 11 * dp, 0xFFFFFFFF, 255, true);
    }
}
