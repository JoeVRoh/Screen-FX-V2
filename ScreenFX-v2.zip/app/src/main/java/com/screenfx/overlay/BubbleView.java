package com.screenfx.overlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.SweepGradient;
import android.view.View;

/** Small floating button: tap = toggle Play mode, drag = move, long-press = open settings. */
final class BubbleView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float dp;
    private boolean active;
    private int[] pal = Config.PALETTES[0];
    private SweepGradient ring;

    BubbleView(Context c) {
        super(c);
        Gfx.init();
        dp = getResources().getDisplayMetrics().density;
        setContentDescription("ScreenFX play mode toggle");
    }

    void setActive(boolean a) {
        active = a;
        invalidate();
    }

    void setPalette(int[] palette) {
        pal = palette;
        ring = null;
        invalidate();
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), cx = w / 2f, cy = getHeight() / 2f;
        float r = Math.min(w, getHeight()) / 2f - 4 * dp;
        long ms = System.currentTimeMillis();
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        if (active) {
            float pulse = 0.5f + 0.5f * (float) Math.sin(ms / 160.0);
            Gfx.dot(c, cx, cy, r + 4 * dp, 0xFFFF2D6F, Gfx.alpha(0.5f + 0.4f * pulse), true);
            p.setColor(0xFFFF2D6F);
            c.drawCircle(cx, cy, r, p);
        } else {
            p.setColor(0xD9161821);
            c.drawCircle(cx, cy, r, p);
        }
        if (ring == null) {
            int[] cols = new int[pal.length + 1];
            System.arraycopy(pal, 0, cols, 0, pal.length);
            cols[pal.length] = pal[0];
            ring = new SweepGradient(cx, cy, cols, null);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3 * dp);
        p.setShader(ring);
        p.setColor(0xFFFFFFFF);
        c.drawCircle(cx, cy, r - 1.5f * dp, p);
        p.setShader(null);

        // sparkle icon
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFFFFF);
        c.save();
        c.translate(cx, cy);
        c.rotate(active ? (ms % 3600) / 10f : 0);
        c.scale(r * 0.52f, r * 0.52f);
        c.drawPath(Gfx.star, p);
        c.restore();
        if (active) postInvalidateOnAnimation();
    }
}
