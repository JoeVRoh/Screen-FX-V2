package com.screenfx.overlay;

import android.graphics.Canvas;

import java.util.Random;

/** Fireball that streaks toward a target point, or flies along a swipe direction. */
final class FireballFx extends Fx {
    float x, y, vx, vy;
    final float tx, ty, scale, speed;
    final boolean targeted, crack;
    final ParticleFx trail;

    FireballFx(ParticleFx trail, float x, float y, float vx, float vy, float tx, float ty, boolean targeted,
               float speed, float scale, float maxLife, boolean crack) {
        this.trail = trail;
        this.x = x;
        this.y = y;
        this.vx = vx;
        this.vy = vy;
        this.tx = tx;
        this.ty = ty;
        this.targeted = targeted;
        this.speed = speed;
        this.scale = scale;
        this.life = maxLife;
        this.crack = crack;
        trail.keepAlive = true;
    }

    @Override
    boolean update(FxView w, float dt) {
        float dp = w.dp;
        Random r = w.rnd;
        if (targeted) {
            float dx = tx - x, dy = ty - y;
            float dist = (float) Math.hypot(dx, dy);
            float stepLen = speed * dt;
            if (dist <= stepLen || dist < 1 || age > life) {
                x = tx;
                y = ty;
                Spawner.explosion(w, x, y, scale, true, crack, 0);
                trail.keepAlive = false;
                return false;
            }
            vx = dx / dist * speed;
            vy = dy / dist * speed;
            x += vx * dt;
            y += vy * dt;
        } else {
            vy += 250 * dp * dt;
            x += vx * dt;
            y += vy * dt;
            float m = 60 * dp;
            boolean out = x < -m || y < -m || x > w.getWidth() + m || y > w.getHeight() + m;
            if (out || age >= life) {
                if (!out) Spawner.explosion(w, x, y, scale, true, crack, 0);
                trail.keepAlive = false;
                return false;
            }
        }
        for (int k = 0; k < 3; k++) {
            Particle p = trail.add(Particle.FLAME,
                    x + (r.nextFloat() - 0.5f) * 10 * dp * scale, y + (r.nextFloat() - 0.5f) * 10 * dp * scale,
                    -vx * 0.06f + (r.nextFloat() - 0.5f) * 80 * dp, -vy * 0.06f + (r.nextFloat() - 0.5f) * 80 * dp,
                    0.3f + r.nextFloat() * 0.3f, (12 + r.nextFloat() * 10) * dp * scale, 0xFFFFE082);
            p.color2 = 0xFFFF3D00;
            p.grow = -18 * dp * scale;
            p.add = true;
        }
        if (r.nextFloat() < 0.3f) {
            Particle s = trail.add(Particle.SMOKE, x, y, (r.nextFloat() - 0.5f) * 30 * dp, -30 * dp,
                    0.9f, 12 * dp * scale, 0xFF2B2B2B);
            s.grow = 30 * dp * scale;
            s.baseAlpha = 0.35f;
        }
        return true;
    }

    @Override
    void draw(Canvas c, FxView w) {
        float dp = w.dp * scale;
        float fl = 0.9f + 0.1f * w.rnd.nextFloat();
        Gfx.dot(c, x, y, 36 * dp * fl, 0xFFFF6D00, 180, true);
        Gfx.dot(c, x, y, 20 * dp * fl, 0xFFFFC400, 230, true);
        Gfx.dot(c, x, y, 10 * dp, 0xFFFFFFFF, 255, true);
    }
}
