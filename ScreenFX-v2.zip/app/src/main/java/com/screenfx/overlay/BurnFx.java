package com.screenfx.overlay;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

/** A glowing burn line left by a laser sweep; cools from orange to dark, then fades. */
final class BurnFx extends Fx {
    final Path path;

    BurnFx(Path path, float life) {
        this.path = path;
        this.life = life;
    }

    @Override
    boolean update(FxView w, float dt) {
        return age < life;
    }

    @Override
    void draw(Canvas c, FxView w) {
        float a = 1f;
        float fadeStart = life * 0.75f;
        if (age > fadeStart) a = 1 - (age - fadeStart) / (life - fadeStart);
        float heat = Math.max(0, 1 - age / 1.5f);
        Paint s = Gfx.stroke;
        if (heat > 0) {
            s.setColor(0xFFFF9100);
            s.setAlpha(Gfx.alpha(0.3f * heat));
            s.setStrokeWidth(10 * w.dp);
            c.drawPath(path, s);
        }
        s.setColor(Gfx.lerp(0xFFFFAB40, 0xFF2B1A12, 1 - heat));
        s.setAlpha(Gfx.alpha(0.85f * a));
        s.setStrokeWidth(3.5f * w.dp);
        c.drawPath(path, s);
    }
}
