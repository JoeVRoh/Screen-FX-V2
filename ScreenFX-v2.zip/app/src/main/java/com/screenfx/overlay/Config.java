package com.screenfx.overlay;

import android.content.Context;
import android.content.SharedPreferences;

/** All user settings, themes and templates. Stored in SharedPreferences. */
public final class Config {
    public static final String PREFS = "screenfx";

    public static final String K_THEME = "theme", K_BORDER = "border", K_TAP = "tap", K_HOLD = "hold",
            K_SWIPE = "swipe", K_BORDER_WIDTH = "border_width", K_BORDER_SPEED = "border_speed",
            K_BORDER_ALPHA = "border_alpha", K_CORNER = "corner", K_SIZE = "size",
            K_CRACK_SECONDS = "crack_seconds", K_FLASH = "flash_shake", K_HAPTICS = "haptics",
            K_BUBBLE = "bubble", K_TEMPLATE = "template",
            K_SOUND = "sound", K_VOLUME = "volume", K_PASS_TAPS = "pass_taps";

    // ---- Color themes ----
    public static final String[] THEME_NAMES = {"Neon", "Inferno", "Ocean", "Candy", "Storm", "Gold", "Forest", "Mono", "Toxic"};
    public static final int[][] PALETTES = {
            {0xFF00E5FF, 0xFFFF2BD6, 0xFF7CFF4F, 0xFFFFE600},
            {0xFFFFF176, 0xFFFFA000, 0xFFFF5722, 0xFFD50000},
            {0xFF64FFDA, 0xFF00B8D4, 0xFF2979FF, 0xFF1A237E},
            {0xFFFF80AB, 0xFFB388FF, 0xFF84FFFF, 0xFFFFF59D},
            {0xFFE0F7FA, 0xFF7C4DFF, 0xFF40C4FF, 0xFF536DFE},
            {0xFFFFF8E1, 0xFFFFD54F, 0xFFFFB300, 0xFFC68400},
            {0xFFC6FF00, 0xFF76FF03, 0xFF00E676, 0xFF00897B},
            {0xFFFFFFFF, 0xFFE0E0E0, 0xFFBDBDBD, 0xFF9E9E9E},
            {0xFFB2FF59, 0xFF76FF03, 0xFFD4E157, 0xFF558B2F},
    };

    // ---- Border styles ----
    public static final String[] BORDER_NAMES = {"Off", "Glow pulse", "Rainbow chase", "Marquee lights", "Sparkle", "Flames", "Lightning", "Gas fog"};
    public static final int B_OFF = 0, B_GLOW = 1, B_RAINBOW = 2, B_MARQUEE = 3, B_SPARKLE = 4, B_FLAMES = 5, B_LIGHTNING = 6, B_GAS = 7;

    // ---- Gesture effects ----
    public static final String[] EFFECT_NAMES = {"None", "Pop", "Cloud", "Fireball", "Bomb", "Shot + cracks", "Sparkles", "Ripple",
            "Gas (fart)", "Lightning", "Laser", "Paint splat", "Hearts", "Fireworks"};
    public static final int E_NONE = 0, E_POP = 1, E_CLOUD = 2, E_FIREBALL = 3, E_BOMB = 4, E_SHOT = 5, E_SPARKLE = 6, E_RIPPLE = 7,
            E_GAS = 8, E_LIGHTNING = 9, E_LASER = 10, E_PAINT = 11, E_HEARTS = 12, E_FIREWORKS = 13;

    // ---- Templates (starting points the user can then customize) ----
    public static final class Template {
        public final String name;
        public final int theme, border, tap, hold, swipe;

        Template(String name, int theme, int border, int tap, int hold, int swipe) {
            this.name = name;
            this.theme = theme;
            this.border = border;
            this.tap = tap;
            this.hold = hold;
            this.swipe = swipe;
        }
    }

    public static final Template[] TEMPLATES = {
            new Template("Arcade", 0, B_RAINBOW, E_POP, E_FIREBALL, E_SPARKLE),
            new Template("Inferno", 1, B_FLAMES, E_FIREBALL, E_BOMB, E_FIREBALL),
            new Template("Warzone", 4, B_LIGHTNING, E_SHOT, E_BOMB, E_SHOT),
            new Template("Party", 3, B_MARQUEE, E_POP, E_SPARKLE, E_POP),
            new Template("Dreamy", 2, B_GLOW, E_CLOUD, E_RIPPLE, E_SPARKLE),
            new Template("Royal", 5, B_SPARKLE, E_SPARKLE, E_POP, E_SPARKLE),
            new Template("Stormy", 4, B_LIGHTNING, E_RIPPLE, E_CLOUD, E_CLOUD),
            new Template("Fart Attack", 8, B_GAS, E_GAS, E_GAS, E_GAS),
            new Template("Celebration", 3, B_MARQUEE, E_FIREWORKS, E_HEARTS, E_FIREWORKS),
            new Template("Sci-Fi", 0, B_LIGHTNING, E_LASER, E_LIGHTNING, E_LASER),
            new Template("Art Attack", 3, B_RAINBOW, E_PAINT, E_PAINT, E_PAINT),
            new Template("Love", 3, B_GLOW, E_HEARTS, E_HEARTS, E_HEARTS),
    };

    // ---- Values ----
    public int theme = 0, border = B_RAINBOW, tap = E_POP, hold = E_FIREBALL, swipe = E_SPARKLE;
    public int borderWidthDp = 8, borderSpeedPct = 100, borderAlphaPct = 90, cornerDp = 36;
    public int sizePct = 100, crackSeconds = 12, template = 0, volumePct = 80;
    public boolean flashShake = true, haptics = true, bubble = true, sound = true, passTaps = false;

    public int[] palette() {
        return PALETTES[clamp(theme, 0, PALETTES.length - 1)];
    }

    public static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static Config load(Context c) {
        SharedPreferences p = prefs(c);
        Config k = new Config();
        k.theme = clamp(p.getInt(K_THEME, k.theme), 0, PALETTES.length - 1);
        k.border = clamp(p.getInt(K_BORDER, k.border), 0, BORDER_NAMES.length - 1);
        k.tap = clamp(p.getInt(K_TAP, k.tap), 0, EFFECT_NAMES.length - 1);
        k.hold = clamp(p.getInt(K_HOLD, k.hold), 0, EFFECT_NAMES.length - 1);
        k.swipe = clamp(p.getInt(K_SWIPE, k.swipe), 0, EFFECT_NAMES.length - 1);
        k.borderWidthDp = p.getInt(K_BORDER_WIDTH, k.borderWidthDp);
        k.borderSpeedPct = p.getInt(K_BORDER_SPEED, k.borderSpeedPct);
        k.borderAlphaPct = p.getInt(K_BORDER_ALPHA, k.borderAlphaPct);
        k.cornerDp = p.getInt(K_CORNER, k.cornerDp);
        k.sizePct = p.getInt(K_SIZE, k.sizePct);
        k.crackSeconds = Math.max(1, p.getInt(K_CRACK_SECONDS, k.crackSeconds));
        k.template = p.getInt(K_TEMPLATE, k.template);
        k.flashShake = p.getBoolean(K_FLASH, k.flashShake);
        k.haptics = p.getBoolean(K_HAPTICS, k.haptics);
        k.bubble = p.getBoolean(K_BUBBLE, k.bubble);
        k.sound = p.getBoolean(K_SOUND, k.sound);
        k.volumePct = p.getInt(K_VOLUME, k.volumePct);
        k.passTaps = p.getBoolean(K_PASS_TAPS, k.passTaps);
        return k;
    }

    public static void applyTemplate(Context c, int index) {
        Template t = TEMPLATES[clamp(index, 0, TEMPLATES.length - 1)];
        prefs(c).edit()
                .putInt(K_TEMPLATE, index)
                .putInt(K_THEME, t.theme)
                .putInt(K_BORDER, t.border)
                .putInt(K_TAP, t.tap)
                .putInt(K_HOLD, t.hold)
                .putInt(K_SWIPE, t.swipe)
                .apply();
    }

    static int clamp(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
