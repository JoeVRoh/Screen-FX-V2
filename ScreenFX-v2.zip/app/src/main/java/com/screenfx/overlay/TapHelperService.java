package com.screenfx.overlay;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;

/**
 * Optional "Tap helper". In Play mode the overlay catches your touches to draw effects;
 * this service then replays the same tap / hold / swipe to the app underneath, so the phone keeps working.
 * It reads nothing on screen and collects no data: it only performs gestures ScreenFX hands it.
 */
public class TapHelperService extends AccessibilityService {
    static volatile TapHelperService instance;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // not used
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    /** Replays a one-finger gesture. Calls done when finished (or immediately if it couldn't start). */
    boolean replay(float[] xs, float[] ys, int n, long durationMs, final Runnable done) {
        if (n < 1) return false;
        Path p = new Path();
        p.moveTo(Math.max(0, xs[0]), Math.max(0, ys[0]));
        for (int i = 1; i < n; i++) p.lineTo(Math.max(0, xs[i]), Math.max(0, ys[i]));
        long dur = Math.max(1, Math.min(durationMs, Math.min(10000, GestureDescription.getMaxGestureDuration())));
        if (n == 1 && dur > 350) dur = Math.max(dur, 650); // make sure a held finger registers as a long-press
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, dur))
                .build();
        try {
            return dispatchGesture(g, new GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription d) {
                    done.run();
                }

                @Override
                public void onCancelled(GestureDescription d) {
                    done.run();
                }
            }, null);
        } catch (RuntimeException e) {
            return false;
        }
    }
}
