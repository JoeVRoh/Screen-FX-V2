package com.screenfx.overlay;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;

import java.util.HashMap;

/** Shared drawing helpers. All drawing happens on the UI thread. */
final class Gfx {
    static final float TAU = (float) (Math.PI * 2);

    static Bitmap dot;
    static Rect src;
    static final Paint sprite = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    static final Paint spriteAdd = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    static final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    static final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    static final RectF tmp = new RectF();
    /** Unit 4-point sparkle star (radius 1). */
    static final Path star = new Path();
    /** Unit glass shard triangle. */
    static final Path shard = new Path();
    /** Unit heart (about 2 units tall). */
    static final Path heart = new Path();
    private static final HashMap<Integer, ColorFilter> filters = new HashMap<>();

    private Gfx() {
    }

    static void init() {
        if (dot != null) return;
        int s = 128;
        dot = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(dot);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new RadialGradient(s / 2f, s / 2f, s / 2f,
                new int[]{0xFFFFFFFF, 0xC0FFFFFF, 0x50FFFFFF, 0x00FFFFFF},
                new float[]{0f, 0.22f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(s / 2f, s / 2f, s / 2f, p);
        src = new Rect(0, 0, s, s);

        spriteAdd.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));
        fill.setStyle(Paint.Style.FILL);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);

        float k = 0.2f;
        star.moveTo(0, -1);
        star.lineTo(k, -k);
        star.lineTo(1, 0);
        star.lineTo(k, k);
        star.lineTo(0, 1);
        star.lineTo(-k, k);
        star.lineTo(-1, 0);
        star.lineTo(-k, -k);
        star.close();

        shard.moveTo(0, -1);
        shard.lineTo(0.8f, 0.7f);
        shard.lineTo(-0.6f, 0.9f);
        shard.close();

        heart.moveTo(0, 0.9f);
        heart.cubicTo(-1.4f, -0.1f, -0.6f, -1.1f, 0, -0.45f);
        heart.cubicTo(0.6f, -1.1f, 1.4f, -0.1f, 0, 0.9f);
        heart.close();
    }

    private static ColorFilter filter(int color) {
        int key = color & 0x00F8F8F8;
        ColorFilter f = filters.get(key);
        if (f == null) {
            if (filters.size() > 3000) filters.clear();
            f = new PorterDuffColorFilter(0xFF000000 | key, PorterDuff.Mode.SRC_IN);
            filters.put(key, f);
        }
        return f;
    }

    /** Soft glowing dot of radius r. */
    static void dot(Canvas c, float x, float y, float r, int color, int alpha, boolean additive) {
        if (r <= 0.5f || alpha <= 0) return;
        Paint p = additive ? spriteAdd : sprite;
        p.setColorFilter(filter(color));
        p.setAlpha(alpha > 255 ? 255 : alpha);
        tmp.set(x - r, y - r, x + r, y + r);
        c.drawBitmap(dot, src, tmp, p);
    }

    static int lerp(int a, int b, float t) {
        if (t <= 0) return a;
        if (t >= 1) return b;
        int aa = a >>> 24, ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int ba = b >>> 24, br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return ((int) (aa + (ba - aa) * t) << 24) | ((int) (ar + (br - ar) * t) << 16)
                | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    /** Smoothly cycles through a palette; u = 1.0 moves one color forward. */
    static int cycle(int[] pal, float u) {
        int n = pal.length;
        float f = u % n;
        if (f < 0) f += n;
        int i = (int) f;
        return lerp(pal[i % n], pal[(i + 1) % n], f - i);
    }

    static int alpha(float a) {
        int v = (int) (a * 255);
        return v < 0 ? 0 : (v > 255 ? 255 : v);
    }
}
