package com.screenfx.overlay;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;

import java.util.Random;

/** A drifting green gas cloud with wavy stink lines. Big ones tint the whole screen. */
final class GasFx extends Fx {
    static final int[] GAS = {0xFFAED581, 0xFFC5E1A5, 0xFFD4E157, 0xFF9CCC65, 0xFFAFB42B};
    static final int N = 10;
    float x, y;
    final float scale;
    final boolean big;
    final float[] px = new float[N], py = new float[N], vx = new float[N], vy = new float[N], pr = new float[N], ph = new float[N];
    final int[] col = new int[N];
    private final Path line = new Path();

    GasFx(FxView w, float x, float y, float scale, boolean big, float life) {
        this.x = x;
        this.y = y;
        this.scale = scale;
        this.big = big;
        this.life = life;
        float dp = w.dp;
        Random r = w.rnd;
        int tint = w.cfg.palette()[0];
        for (int i = 0; i < N; i++) {
            float a = r.nextFloat() * Gfx.TAU, sp = (20 + r.nextFloat() * 45) * dp * scale;
            px[i] = (r.nextFloat() - 0.5f) * 12 * dp;
            py[i] = (r.nextFloat() - 0.5f) * 12 * dp;
            vx[i] = cos(a) * sp;
            vy[i] = sin(a) * sp * 0.7f - 10 * dp;
            pr[i] = (18 + r.nextFloat() * 22) * dp;
            ph[i] = r.nextFloat() * 6;
            col[i] = Gfx.lerp(GAS[r.nextInt(GAS.length)], tint, 0.15f);
        }
    }

    @Override
    boolean update(FxView w, float dt) {
        float d = 1f / (1f + 0.9f * dt);
        for (int i = 0; i < N; i++) {
            vx[i] *= d;
            vy[i] *= d;
            px[i] += vx[i] * dt;
            py[i] += vy[i] * dt;
        }
        y -= 10 * w.dp * scale * dt;
        return age < life;
    }

    @Override
    void draw(Canvas c, FxView w) {
        float dp = w.dp;
        float grow = scale * (0.45f + 0.9f * easeOut(age / (life * 0.5f)));
        float a = Math.min(1, age / 0.15f);
        if (age > life - 1.2f) a *= Math.max(0, (life - age) / 1.2f);
        if (big) c.drawColor(Color.argb(Gfx.alpha(0.13f * a), 130, 170, 40));
        for (int i = 0; i < N; i++) {
            float wob = 1 + 0.1f * sin(age * 3 + ph[i]);
            Gfx.dot(c, x + px[i] * grow / scale, y + py[i] * grow / scale, pr[i] * 1.5f * grow * wob, col[i],
                    Gfx.alpha(0.55f * a), false);
        }
        // stink lines rising above the cloud
        Paint s = Gfx.stroke;
        s.setColor(0xFF7CB342);
        s.setStrokeWidth(2.6f * dp * Math.max(0.6f, scale));
        float top = y - 45 * dp * grow;
        float rise = (age * 22 * dp) % (18 * dp);
        for (int k = 0; k < 3; k++) {
            float lx = x + (k - 1) * 22 * dp * grow;
            line.reset();
            for (int j = 0; j <= 10; j++) {
                float yy = top - rise - j * 4 * dp * grow;
                float xx = lx + sin(j * 0.9f + age * 6 + k * 2) * 5 * dp * grow;
                if (j == 0) line.moveTo(xx, yy);
                else line.lineTo(xx, yy);
            }
            s.setAlpha(Gfx.alpha(0.75f * a));
            c.drawPath(line, s);
        }
    }
}
