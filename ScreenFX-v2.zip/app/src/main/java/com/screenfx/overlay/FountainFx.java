package com.screenfx.overlay;

import android.graphics.Canvas;

import java.util.Random;

/** Emits sparkle stars upward for a while (hold sparkle). */
final class FountainFx extends Fx {
    final float x, y, scale;
    final int[] pal;
    final ParticleFx out;
    int kind = Particle.STAR;
    private float acc;

    FountainFx(ParticleFx out, float x, float y, float scale, int[] pal, float life) {
        this.out = out;
        this.x = x;
        this.y = y;
        this.scale = scale;
        this.pal = pal;
        this.life = life;
        out.keepAlive = true;
    }

    @Override
    boolean update(FxView w, float dt) {
        float dp = w.dp;
        Random r = w.rnd;
        acc += dt * 70;
        while (acc >= 1) {
            acc -= 1;
            Particle p = out.add(kind, x, y, (r.nextFloat() - 0.5f) * 320 * dp * scale,
                    -(350 + r.nextFloat() * 450) * dp * scale, 0.9f + r.nextFloat() * 0.7f,
                    (5 + r.nextFloat() * 7) * dp * scale, pal[r.nextInt(pal.length)]);
            p.gravity = kind == Particle.HEART ? 300 * dp : 900 * dp;
            p.drag = 0.6f;
            p.phase = r.nextFloat() * 6;
            p.vrot = (r.nextFloat() - 0.5f) * 300;
        }
        boolean alive = age < life;
        if (!alive) out.keepAlive = false;
        return alive;
    }

    @Override
    void draw(Canvas c, FxView w) {
        Gfx.dot(c, x, y, 26 * w.dp * scale, pal[0], 150, true);
    }
}
