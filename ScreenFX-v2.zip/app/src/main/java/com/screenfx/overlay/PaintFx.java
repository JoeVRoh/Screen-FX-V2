package com.screenfx.overlay;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

import java.util.Random;

/** A paint splat decal with droplets and drips that run down the screen. */
final class PaintFx extends Fx {
    final float x, y, r;
    final int color;
    private final Path blob = new Path();
    private final float[] dx, dy, dr, kx, ky, kw, kl;

    PaintFx(FxView w, float x, float y, float r, int color) {
        this.x = x;
        this.y = y;
        this.r = r;
        this.color = color;
        this.life = w.cfg.crackSeconds;
        Random rnd = w.rnd;
        int v = 22;
        float[] ptx = new float[v], pty = new float[v];
        for (int i = 0; i < v; i++) {
            float a = i * Gfx.TAU / v;
            float rad = r * (0.75f + rnd.nextFloat() * 0.35f);
            if (rnd.nextFloat() < 0.2f) rad *= 1.3f + rnd.nextFloat() * 0.4f;
            ptx[i] = cos(a) * rad;
            pty[i] = sin(a) * rad;
        }
        blob.moveTo((ptx[v - 1] + ptx[0]) / 2, (pty[v - 1] + pty[0]) / 2);
        for (int i = 0; i < v; i++) {
            int j = (i + 1) % v;
            blob.quadTo(ptx[i], pty[i], (ptx[i] + ptx[j]) / 2, (pty[i] + pty[j]) / 2);
        }
        blob.close();
        int drops = 6 + rnd.nextInt(7);
        dx = new float[drops];
        dy = new float[drops];
        dr = new float[drops];
        for (int i = 0; i < drops; i++) {
            float a = rnd.nextFloat() * Gfx.TAU, d = r * (1.15f + rnd.nextFloat() * 0.9f);
            dx[i] = cos(a) * d;
            dy[i] = sin(a) * d;
            dr[i] = r * (0.05f + rnd.nextFloat() * 0.11f);
        }
        int drips = 2 + rnd.nextInt(3);
        kx = new float[drips];
        ky = new float[drips];
        kw = new float[drips];
        kl = new float[drips];
        for (int i = 0; i < drips; i++) {
            kx[i] = (rnd.nextFloat() - 0.5f) * 1.2f * r;
            ky[i] = r * (0.3f + rnd.nextFloat() * 0.3f);
            kw[i] = r * (0.08f + rnd.nextFloat() * 0.08f);
            kl[i] = r * (0.6f + rnd.nextFloat() * 1.2f);
        }
    }

    @Override
    boolean update(FxView w, float dt) {
        return age < life;
    }

    @Override
    void draw(Canvas c, FxView w) {
        float a = 1f;
        float fadeStart = life * 0.75f;
        if (age > fadeStart) a = 1 - (age - fadeStart) / (life - fadeStart);
        float s = age < 0.12f ? 1.08f * easeOut(age / 0.12f) : 1f;
        Paint f = Gfx.fill;
        f.setColor(color);
        f.setAlpha(Gfx.alpha(0.9f * a));
        c.save();
        c.translate(x, y);
        c.scale(s, s);
        c.drawPath(blob, f);
        for (int i = 0; i < dx.length; i++) c.drawCircle(dx[i], dy[i], dr[i], f);
        float run = easeOut(Math.min(1, age / 2.2f));
        for (int i = 0; i < kx.length; i++) {
            float len = kl[i] * run;
            Gfx.tmp.set(kx[i] - kw[i] / 2, ky[i], kx[i] + kw[i] / 2, ky[i] + len);
            c.drawRoundRect(Gfx.tmp, kw[i] / 2, kw[i] / 2, f);
            c.drawCircle(kx[i], ky[i] + len, kw[i] * 0.75f, f);
        }
        Gfx.dot(c, -r * 0.3f, -r * 0.32f, r * 0.4f, 0xFFFFFFFF, Gfx.alpha(0.28f * a), false);
        c.restore();
    }
}
