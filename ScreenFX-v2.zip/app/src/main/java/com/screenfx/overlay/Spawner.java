package com.screenfx.overlay;

import java.util.Random;

/** Turns a gesture (tap / hold / swipe) into the chosen effect and its sounds. */
final class Spawner {
    private Spawner() {
    }

    static void spawn(FxView w, int type, int mode, float x, float y, float vx, float vy, float[] path, int pn) {
        float s = w.cfg.sizePct / 100f;
        float dp = w.dp;
        Random r = w.rnd;
        int[] pal = w.cfg.palette();
        // For swipes, make sure there's a usable direction even if the finger stopped before lifting.
        if (mode == FxView.SWIPE && Math.hypot(vx, vy) < 50 * dp && path != null && pn > 1) {
            float dx = x - path[0], dy = y - path[1];
            float len = (float) Math.max(1, Math.hypot(dx, dy));
            vx = dx / len * 900 * dp;
            vy = dy / len * 900 * dp;
        }
        boolean hasPath = path != null && pn > 0;
        int step = hasPath ? Math.max(1, pn / 12) : 1;
        if (mode == FxView.SWIPE && !hasPath) {
            path = new float[]{x, y};
            pn = 1;
        }

        switch (type) {
            case Config.E_POP:
                if (mode == FxView.TAP) {
                    pop(w, x, y, s, 0, 0.8f);
                } else if (mode == FxView.HOLD) {
                    pop(w, x, y, s * 1.8f, 0, 1f);
                    for (int i = 0; i < 5; i++) {
                        float a = i * Gfx.TAU / 5 + r.nextFloat() * 0.5f;
                        pop(w, x + Fx.cos(a) * 95 * dp * s, y + Fx.sin(a) * 95 * dp * s, s * 0.8f, 0.12f + i * 0.07f, 0.6f);
                    }
                } else {
                    int k = 0;
                    for (int i = 0; i < pn; i += step, k++) pop(w, path[2 * i], path[2 * i + 1], s * 0.7f, k * 0.04f, 0.45f);
                }
                break;

            case Config.E_CLOUD:
                if (mode == FxView.TAP) {
                    w.add(new CloudFx(w, x, y, 0, 0, s, false, 2.6f));
                    w.sound(Sfx.PUFF, 0, 0.8f);
                } else if (mode == FxView.HOLD) {
                    w.add(new CloudFx(w, x, y, 0, 0, s * 1.5f, true, 3.2f));
                    w.sound(Sfx.PUFF, 0, 1f);
                } else {
                    int k = 0;
                    for (int i = 0; i < pn && k < 3; i += Math.max(1, pn / 3), k++) {
                        CloudFx c = new CloudFx(w, path[2 * i], path[2 * i + 1], vx * 0.25f, vy * 0.25f, s * 0.85f, false, 2.8f);
                        c.delay = k * 0.06f;
                        w.add(c);
                    }
                    w.sound(Sfx.WHOOSH, 0, 0.6f);
                }
                break;

            case Config.E_FIREBALL: {
                ParticleFx trail = new ParticleFx();
                w.add(trail);
                if (mode == FxView.SWIPE) {
                    float[] v = clamp(vx, vy, 900 * dp, 2800 * dp);
                    w.add(new FireballFx(trail, x, y, v[0], v[1], 0, 0, false, 0, s, 1.4f, false));
                } else {
                    boolean big = mode == FxView.HOLD;
                    float sx = big ? (x < w.getWidth() / 2f ? -40 * dp : w.getWidth() + 40 * dp)
                            : x + (r.nextFloat() - 0.5f) * 500 * dp;
                    float sy = -60 * dp;
                    w.add(new FireballFx(trail, sx, sy, 0, 0, x, y, true, (big ? 1300 : 1600) * dp,
                            big ? s * 1.8f : s, 10f, big));
                }
                w.sound(Sfx.WHOOSH, 0, 0.8f);
                break;
            }

            case Config.E_BOMB: {
                ParticleFx sparks = new ParticleFx();
                w.add(sparks);
                if (mode == FxView.TAP) {
                    w.add(new BombFx(w, sparks, BombFx.DROP, x, -60 * dp, 0, 0, y, s, 0.9f));
                } else if (mode == FxView.HOLD) {
                    w.add(new BombFx(w, sparks, BombFx.PLACE, x, y, 0, 0, y, s * 1.5f, 1.3f));
                } else {
                    float[] v = clamp(vx, vy, 400 * dp, 2200 * dp);
                    w.add(new BombFx(w, sparks, BombFx.THROW, x, y, v[0], v[1], 0, s, 1.4f));
                }
                w.sound(Sfx.FUSE, 0.1f, 0.6f);
                break;
            }

            case Config.E_SHOT:
                if (mode == FxView.TAP) {
                    shot(w, x, y, s, 0, true);
                } else if (mode == FxView.HOLD) {
                    for (int i = 0; i < 7; i++) {
                        float a = r.nextFloat() * Gfx.TAU, d = r.nextFloat() * 75 * dp * s;
                        shot(w, x + Fx.cos(a) * d, y + Fx.sin(a) * d, s * 0.6f, r.nextFloat() * 0.04f, i == 0);
                    }
                    w.shake(8 * dp);
                } else {
                    int k = 0;
                    for (int i = 0; i < pn && k < 10; i += step, k++) {
                        shot(w, path[2 * i] + (r.nextFloat() - 0.5f) * 20 * dp, path[2 * i + 1] + (r.nextFloat() - 0.5f) * 20 * dp,
                                s * 0.7f, k * 0.07f, true);
                    }
                }
                break;

            case Config.E_SPARKLE:
                if (mode == FxView.TAP) {
                    sparkle(w, x, y, s, 0, 20);
                } else if (mode == FxView.HOLD) {
                    ParticleFx out = new ParticleFx();
                    w.add(out);
                    w.add(new FountainFx(out, x, y, s, pal, 1.6f));
                    w.sound(Sfx.CHIME, 0.6f, 0.7f);
                } else {
                    int k = 0;
                    for (int i = 0; i < pn; i++, k++) sparkle(w, path[2 * i], path[2 * i + 1], s * 0.6f, k * 0.015f, 5);
                }
                w.sound(Sfx.CHIME, 0, 0.7f);
                break;

            case Config.E_RIPPLE:
                if (mode == FxView.TAP) {
                    ripple(w, x, y, s, 0, 3);
                    w.sound(Sfx.DROP, 0, 0.8f);
                } else if (mode == FxView.HOLD) {
                    ripple(w, x, y, s * 1.8f, 0, 6);
                    w.sound(Sfx.DROP, 0, 1f);
                    w.sound(Sfx.DROP, 0.3f, 0.6f);
                } else {
                    int k = 0;
                    for (int i = 0; i < pn; i += step, k++) {
                        ripple(w, path[2 * i], path[2 * i + 1], s * 0.6f, k * 0.05f, 2);
                        if (k % 3 == 0) w.sound(Sfx.DROP, k * 0.05f, 0.45f);
                    }
                }
                break;

            case Config.E_GAS:
                if (mode == FxView.TAP) {
                    w.add(new GasFx(w, x, y, s, false, 3.2f));
                    w.sound(Sfx.randomFart(), 0, 1f);
                } else if (mode == FxView.HOLD) {
                    w.add(new GasFx(w, x, y, s * 1.7f, true, 5.5f));
                    w.sound(Sfx.FART_LONG, 0, 1f);
                } else {
                    int k = 0;
                    for (int i = 0; i < pn && k < 8; i += Math.max(1, pn / 8), k++) {
                        GasFx g = new GasFx(w, path[2 * i], path[2 * i + 1], s * 0.6f, false, 2.4f);
                        g.delay = k * 0.05f;
                        w.add(g);
                    }
                    w.sound(Sfx.FART_RIPPLE, 0, 1f);
                }
                break;

            case Config.E_LIGHTNING:
                if (mode == FxView.TAP) {
                    strike(w, x, y, s, 0, false, 1f);
                } else if (mode == FxView.HOLD) {
                    strike(w, x, y, s, 0, false, 1f);
                    strike(w, x, y, s * 1.2f, 0.18f, false, 0.5f);
                    strike(w, x, y, s * 1.4f, 0.36f, true, 0.8f);
                } else {
                    int k = 0;
                    for (int i = 0; i < pn && k < 5; i += Math.max(1, pn / 5), k++)
                        strike(w, path[2 * i], path[2 * i + 1], s * 0.8f, k * 0.09f, false, k == 0 ? 1f : 0.4f);
                }
                break;

            case Config.E_LASER: {
                int col = pal[r.nextInt(pal.length)];
                float W = w.getWidth(), H = w.getHeight();
                if (mode == FxView.TAP) {
                    laser(w, W / 2f, H + 10 * dp, new float[]{x, y}, 1, col, s, 0.3f, false, 0);
                } else if (mode == FxView.HOLD) {
                    laser(w, 0, H, new float[]{x, y}, 1, col, s * 1.3f, 0.8f, false, 0);
                    laser(w, W, H, new float[]{x, y}, 1, col, s * 1.3f, 0.8f, false, 0.05f);
                    laser(w, W / 2f, H + 10 * dp, new float[]{x, y}, 1, 0xFFFFFFFF, s * 1.3f, 0.8f, true, 0.1f);
                } else {
                    float[] copy = new float[pn * 2];
                    System.arraycopy(path, 0, copy, 0, pn * 2);
                    laser(w, W / 2f, H + 10 * dp, copy, pn, col, s, 0.55f, false, 0);
                }
                break;
            }

            case Config.E_PAINT:
                if (mode == FxView.TAP) {
                    splat(w, x, y, 50 * dp * s, pal[r.nextInt(pal.length)], 0);
                    w.sound(Sfx.SPLAT, 0, 1f);
                } else if (mode == FxView.HOLD) {
                    splat(w, x, y, 62 * dp * s, pal[0], 0);
                    splat(w, x + 40 * dp * s, y - 25 * dp * s, 42 * dp * s, pal[1 % pal.length], 0.1f);
                    splat(w, x - 35 * dp * s, y + 30 * dp * s, 38 * dp * s, pal[2 % pal.length], 0.2f);
                    w.sound(Sfx.SPLAT, 0, 1f);
                    w.sound(Sfx.SPLAT, 0.1f, 0.7f);
                    w.sound(Sfx.SPLAT, 0.2f, 0.6f);
                } else {
                    int col = pal[r.nextInt(pal.length)];
                    int k = 0;
                    for (int i = 0; i < pn && k < 14; i++, k++)
                        splat(w, path[2 * i], path[2 * i + 1], (16 + r.nextFloat() * 12) * dp * s, col, k * 0.03f);
                    w.sound(Sfx.SPLAT, 0, 0.8f);
                    w.sound(Sfx.SPLAT, Math.min(14, pn) * 0.03f * 0.5f, 0.5f);
                }
                break;

            case Config.E_HEARTS:
                if (mode == FxView.TAP) {
                    hearts(w, x, y, s, 0, 9, true);
                } else if (mode == FxView.HOLD) {
                    ParticleFx out = new ParticleFx();
                    w.add(out);
                    FountainFx f = new FountainFx(out, x, y, s, heartColors(pal), 1.6f);
                    f.kind = Particle.HEART;
                    w.add(f);
                    w.sound(Sfx.BLING, 0.7f, 0.6f);
                } else {
                    for (int i = 0; i < pn; i++) hearts(w, path[2 * i], path[2 * i + 1], s * 0.7f, i * 0.02f, 2, false);
                }
                w.sound(Sfx.BLING, 0, 0.8f);
                break;

            case Config.E_FIREWORKS:
                if (mode == FxView.TAP) {
                    firework(w, x, y, s, 0);
                } else if (mode == FxView.HOLD) {
                    firework(w, x, y, s * 1.3f, 0);
                    firework(w, x - 90 * dp * s, y + 40 * dp * s, s * 0.9f, 0.25f);
                    firework(w, x + 90 * dp * s, y + 20 * dp * s, s * 0.9f, 0.5f);
                } else {
                    int k = 0;
                    for (int i = 0; i < pn && k < 3; i += Math.max(1, pn / 3), k++)
                        firework(w, path[2 * i], path[2 * i + 1], s * 0.9f, k * 0.2f);
                }
                break;

            default:
                break;
        }
    }

    private static float[] clamp(float vx, float vy, float min, float max) {
        float m = (float) Math.hypot(vx, vy);
        if (m < 1) return new float[]{0, -min};
        float t = Math.max(min, Math.min(max, m)) / m;
        return new float[]{vx * t, vy * t};
    }

    static void pop(FxView w, float x, float y, float s, float delay, float vol) {
        float dp = w.dp;
        Random r = w.rnd;
        int[] pal = w.cfg.palette();
        ParticleFx p = new ParticleFx();
        p.delay = delay;
        Particle core = p.add(Particle.DOT, x, y, 0, 0, 0.18f, 46 * dp * s, 0xFFFFFFFF);
        core.add = true;
        core.grow = -120 * dp * s;
        for (int i = 0; i < 28; i++) {
            float a = r.nextFloat() * Gfx.TAU, sp = (220 + r.nextFloat() * 480) * dp * s;
            Particle q = p.add(Particle.CONFETTI, x, y, Fx.cos(a) * sp, Fx.sin(a) * sp - 120 * dp * s,
                    0.9f + r.nextFloat() * 0.7f, (6 + r.nextFloat() * 5) * dp * s, pal[r.nextInt(pal.length)]);
            q.gravity = 1100 * dp;
            q.drag = 2.6f;
            q.rot = r.nextFloat() * 360;
            q.vrot = (r.nextFloat() - 0.5f) * 900;
            q.phase = r.nextFloat() * 6.28f;
        }
        for (int i = 0; i < 10; i++) {
            float a = r.nextFloat() * Gfx.TAU, sp = (120 + r.nextFloat() * 260) * dp * s;
            Particle q = p.add(Particle.CIRCLE, x, y, Fx.cos(a) * sp, Fx.sin(a) * sp, 0.45f + r.nextFloat() * 0.25f,
                    (2.5f + r.nextFloat() * 3) * dp * s, pal[r.nextInt(pal.length)]);
            q.drag = 3f;
        }
        RingFx ring = new RingFx(x, y, 72 * dp * s, pal[r.nextInt(pal.length)], 7 * dp * s, 0.45f);
        ring.delay = delay;
        w.add(ring);
        w.add(p);
        w.sound(Sfx.POP, delay, vol);
    }

    static void shot(FxView w, float x, float y, float s, float delay, boolean sound) {
        float dp = w.dp;
        Random r = w.rnd;
        ParticleFx p = new ParticleFx();
        p.delay = delay;
        Particle f1 = p.add(Particle.DOT, x, y, 0, 0, 0.1f, 36 * dp * s, 0xFFFFFFFF);
        f1.add = true;
        Particle f2 = p.add(Particle.DOT, x, y, 0, 0, 0.13f, 22 * dp * s, 0xFFFFB74D);
        f2.add = true;
        for (int i = 0; i < 9; i++) {
            float a = r.nextFloat() * Gfx.TAU, sp = (200 + r.nextFloat() * 450) * dp * s;
            Particle q = p.add(Particle.SHARD, x, y, Fx.cos(a) * sp, Fx.sin(a) * sp, 0.5f + r.nextFloat() * 0.4f,
                    (3 + r.nextFloat() * 4) * dp * s, 0xD0E8F4FF);
            q.gravity = 1600 * dp;
            q.rot = r.nextFloat() * 360;
            q.vrot = (r.nextFloat() - 0.5f) * 720;
        }
        CrackFx c = CrackFx.glass(w, x, y, (70 + r.nextFloat() * 45) * dp * s, true);
        c.delay = delay;
        w.addDecal(c);
        w.add(p);
        if (delay <= 0) w.shake(3 * dp);
        if (sound) w.sound(Sfx.SHOT, delay, 0.9f);
    }

    static void sparkle(FxView w, float x, float y, float s, float delay, int count) {
        float dp = w.dp;
        Random r = w.rnd;
        int[] pal = w.cfg.palette();
        ParticleFx p = new ParticleFx();
        p.delay = delay;
        if (count >= 10) {
            Particle big = p.add(Particle.STAR, x, y, 0, 0, 0.35f, 26 * dp * s, pal[0]);
            big.grow = 30 * dp * s;
            big.vrot = 120;
        }
        for (int i = 0; i < count; i++) {
            float a = r.nextFloat() * Gfx.TAU, sp = (60 + r.nextFloat() * 220) * dp * s;
            Particle q = p.add(Particle.STAR, x, y, Fx.cos(a) * sp, Fx.sin(a) * sp, 0.8f + r.nextFloat() * 0.8f,
                    (5 + r.nextFloat() * 8) * dp * s, pal[r.nextInt(pal.length)]);
            q.drag = 1.5f;
            q.gravity = 120 * dp;
            q.phase = r.nextFloat() * 6;
            q.rot = r.nextFloat() * 90;
        }
        w.add(p);
    }

    static void ripple(FxView w, float x, float y, float s, float delay, int rings) {
        float dp = w.dp;
        int[] pal = w.cfg.palette();
        for (int i = 0; i < rings; i++) {
            RingFx f = new RingFx(x, y, (110 + i * 18) * dp * s, pal[i % pal.length], 5 * dp * s, 0.9f + i * 0.08f);
            f.delay = delay + i * 0.14f;
            w.add(f);
        }
    }

    static void strike(final FxView w, float x, float y, float s, float delay, boolean crack, float vol) {
        float dp = w.dp;
        Random r = w.rnd;
        int[] pal = w.cfg.palette();
        int col = Gfx.lerp(pal[0], 0xFFFFFFFF, 0.3f);
        BoltFx bolt = new BoltFx(BoltFx.jagged(r, x + (r.nextFloat() - 0.5f) * 140 * dp, -20 * dp, x, y, 24 * dp * s),
                col, 1.3f * s, 0.45f);
        bolt.delay = delay;
        w.add(bolt);
        ParticleFx p = new ParticleFx();
        p.delay = delay;
        Particle core = p.add(Particle.DOT, x, y, 0, 0, 0.2f, 50 * dp * s, col);
        core.add = true;
        for (int i = 0; i < 16; i++) {
            float a = r.nextFloat() * Gfx.TAU, sp = (250 + r.nextFloat() * 500) * dp * s;
            Particle q = p.add(Particle.SPARK, x, y, Fx.cos(a) * sp, Fx.sin(a) * sp - 150 * dp, 0.3f + r.nextFloat() * 0.3f,
                    2.2f * dp, i % 2 == 0 ? 0xFFFFFFFF : pal[r.nextInt(pal.length)]);
            q.gravity = 1200 * dp;
        }
        w.add(p);
        CrackFx sc = CrackFx.scorch(w, x, y, 30 * dp * s);
        sc.delay = delay;
        w.addDecal(sc);
        if (crack) {
            CrackFx c = CrackFx.glass(w, x, y, 120 * dp * s, false);
            c.delay = delay;
            w.addDecal(c);
        }
        w.add(new ActionFx(new Runnable() {
            @Override
            public void run() {
                w.flash(0.35f);
                w.shake(7 * w.dp);
            }
        }, delay));
        w.sound(Sfx.THUNDER, delay, vol);
    }

    static void laser(FxView w, float sx, float sy, float[] targets, int n, int color, float s, float life,
                      boolean crack, float delay) {
        ParticleFx sparks = new ParticleFx();
        sparks.delay = delay;
        w.add(sparks);
        LaserFx l = new LaserFx(sparks, sx, sy, targets, n, color, s, life, crack);
        l.delay = delay;
        w.add(l);
        w.sound(Sfx.LASER, delay, 0.8f);
    }

    static void splat(FxView w, float x, float y, float r, int color, float delay) {
        float dp = w.dp;
        Random rnd = w.rnd;
        PaintFx f = new PaintFx(w, x, y, r, color);
        f.delay = delay;
        w.addDecal(f);
        ParticleFx p = new ParticleFx();
        p.delay = delay;
        int count = (int) Math.max(4, r / dp / 4);
        for (int i = 0; i < count; i++) {
            float a = rnd.nextFloat() * Gfx.TAU, sp = (150 + rnd.nextFloat() * 400) * dp * (r / (50 * dp));
            Particle q = p.add(Particle.CIRCLE, x, y, Fx.cos(a) * sp, Fx.sin(a) * sp, 0.4f + rnd.nextFloat() * 0.3f,
                    (2 + rnd.nextFloat() * 4) * dp, color);
            q.gravity = 1400 * dp;
            q.drag = 2f;
        }
        w.add(p);
    }

    static int[] heartColors(int[] pal) {
        return new int[]{0xFFFF4081, 0xFFFF80AB, 0xFFF50057, 0xFFFF1744, pal[0], pal[1 % pal.length]};
    }

    static void hearts(FxView w, float x, float y, float s, float delay, int count, boolean bigOne) {
        float dp = w.dp;
        Random r = w.rnd;
        int[] cols = heartColors(w.cfg.palette());
        ParticleFx p = new ParticleFx();
        p.delay = delay;
        if (bigOne) {
            Particle big = p.add(Particle.HEART, x, y, 0, -30 * dp, 0.6f, 26 * dp * s, cols[0]);
            big.grow = 30 * dp * s;
        }
        for (int i = 0; i < count; i++) {
            Particle q = p.add(Particle.HEART, x + (r.nextFloat() - 0.5f) * 20 * dp, y,
                    (r.nextFloat() - 0.5f) * 320 * dp * s, -(150 + r.nextFloat() * 260) * dp * s,
                    1.4f + r.nextFloat() * 0.8f, (8 + r.nextFloat() * 9) * dp * s, cols[r.nextInt(cols.length)]);
            q.gravity = -40 * dp;
            q.drag = 1.3f;
            q.rot = (r.nextFloat() - 0.5f) * 40;
            q.phase = r.nextFloat() * 6;
        }
        w.add(p);
    }

    static void firework(FxView w, float x, float y, float s, float delay) {
        ParticleFx trail = new ParticleFx();
        trail.delay = delay;
        w.add(trail);
        FireworkFx f = new FireworkFx(w, trail, x, y, s);
        f.delay = delay;
        w.add(f);
    }

    /** Fire burst used by fireballs and bombs. */
    static void explosion(FxView w, float x, float y, float s, boolean scorch, boolean crack, float delay) {
        explosion(w, x, y, s, scorch, crack, delay, true);
    }

    static void explosion(FxView w, float x, float y, float s, boolean scorch, boolean crack, float delay, boolean sound) {
        float dp = w.dp;
        Random r = w.rnd;
        ParticleFx smoke = new ParticleFx(), fire = new ParticleFx();
        smoke.delay = delay;
        fire.delay = delay;
        for (int i = 0; i < 10; i++) {
            float a = r.nextFloat() * Gfx.TAU, sp = (40 + r.nextFloat() * 120) * dp * s;
            Particle q = smoke.add(Particle.SMOKE, x, y, Fx.cos(a) * sp, Fx.sin(a) * sp - 40 * dp, 1.2f + r.nextFloat() * 0.8f,
                    (26 + r.nextFloat() * 22) * dp * s, 0xFF3A3A3A);
            q.grow = 40 * dp * s;
            q.drag = 1.5f;
            q.baseAlpha = 0.55f;
        }
        Particle core = fire.add(Particle.DOT, x, y, 0, 0, 0.16f, 80 * dp * s, 0xFFFFFFFF);
        core.add = true;
        for (int i = 0; i < 36; i++) {
            float a = r.nextFloat() * Gfx.TAU, sp = (80 + r.nextFloat() * 420) * dp * s;
            Particle q = fire.add(Particle.FLAME, x, y, Fx.cos(a) * sp, Fx.sin(a) * sp, 0.35f + r.nextFloat() * 0.5f,
                    (16 + r.nextFloat() * 18) * dp * s, 0xFFFFF59D);
            q.color2 = 0xFFFF3D00;
            q.drag = 3f;
            q.grow = -10 * dp * s;
            q.add = true;
        }
        for (int i = 0; i < 18; i++) {
            float a = r.nextFloat() * Gfx.TAU, sp = (350 + r.nextFloat() * 600) * dp * s;
            Particle q = fire.add(Particle.SPARK, x, y, Fx.cos(a) * sp, Fx.sin(a) * sp, 0.3f + r.nextFloat() * 0.4f,
                    2.5f * dp, 0xFFFFE082);
            q.gravity = 900 * dp;
            q.drag = 1.5f;
        }
        w.add(smoke);
        w.add(fire);
        RingFx ring = new RingFx(x, y, 110 * dp * s, 0xFFFFAB40, 8 * dp * s, 0.4f);
        ring.delay = delay;
        w.add(ring);
        if (scorch) {
            CrackFx sc = CrackFx.scorch(w, x, y, 42 * dp * s);
            sc.delay = delay;
            w.addDecal(sc);
        }
        if (crack) {
            CrackFx c = CrackFx.glass(w, x, y, 120 * dp * s, false);
            c.delay = delay;
            w.addDecal(c);
        }
        if (delay <= 0) w.shake(6 * dp * s);
        if (sound) w.sound(Sfx.BOOM, delay, 0.9f);
    }

    static void bigExplosion(FxView w, float x, float y, float s) {
        float dp = w.dp;
        Random r = w.rnd;
        explosion(w, x, y, s * 1.6f, true, true, 0, false);
        for (int i = 0; i < 3; i++) {
            float a = r.nextFloat() * Gfx.TAU, d = (50 + r.nextFloat() * 50) * dp * s;
            explosion(w, x + Fx.cos(a) * d, y + Fx.sin(a) * d, s * 0.7f, false, false, 0.08f + i * 0.07f, false);
        }
        w.flash(0.5f);
        w.shake(18 * dp * s);
        w.sound(Sfx.BIG_BOOM, 0, 1f);
    }
}
