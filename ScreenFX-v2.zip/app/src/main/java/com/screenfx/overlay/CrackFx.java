package com.screenfx.overlay;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

import java.util.Random;

/** Transparent glass cracks (with optional bullet hole) or a scorch mark. Lives as a decal. */
final class CrackFx extends Fx {
    final float x, y, r;
    final boolean hole, scorch;
    final Path path;

    private CrackFx(FxView w, float x, float y, float r, boolean hole, boolean scorch, boolean rings) {
        this.x = x;
        this.y = y;
        this.r = r;
        this.hole = hole;
        this.scorch = scorch;
        this.life = w.cfg.crackSeconds;
        this.path = build(w.rnd, r, rings, scorch ? 5 : 7);
    }

    static CrackFx glass(FxView w, float x, float y, float r, boolean hole) {
        return new CrackFx(w, x, y, r, hole, false, true);
    }

    static CrackFx scorch(FxView w, float x, float y, float r) {
        return new CrackFx(w, x, y, r, false, true, false);
    }

    private static Path build(Random rnd, float R, boolean rings, int minRays) {
        Path p = new Path();
        int rays = minRays + rnd.nextInt(5);
        int segs = 6;
        float base = rnd.nextFloat() * Gfx.TAU;
        float[][] rx = new float[rays][segs + 1], ry = new float[rays][segs + 1];
        for (int i = 0; i < rays; i++) {
            float a = base + i * Gfx.TAU / rays + (rnd.nextFloat() - 0.5f) * (Gfx.TAU / rays) * 0.6f;
            float L = R * (0.45f + rnd.nextFloat() * 0.7f);
            float seg = L / segs, x = 0, y = 0;
            p.moveTo(0, 0);
            for (int s = 1; s <= segs; s++) {
                a += (rnd.nextFloat() - 0.5f) * 0.45f;
                x += cos(a) * seg;
                y += sin(a) * seg;
                p.lineTo(x, y);
                rx[i][s] = x;
                ry[i][s] = y;
                if (s < segs - 1 && rnd.nextFloat() < 0.32f) {
                    float ba = a + (rnd.nextBoolean() ? 1 : -1) * (0.4f + rnd.nextFloat() * 0.6f);
                    branch(p, rnd, x, y, ba, (L - s * seg) * (0.35f + rnd.nextFloat() * 0.4f));
                    p.moveTo(x, y);
                }
            }
        }
        if (rings) {
            int[] levels = {2, 4};
            for (int idx : levels) {
                for (int i = 0; i < rays; i++) {
                    if (rnd.nextFloat() > 0.75f) continue;
                    int j = (i + 1) % rays;
                    float x1 = rx[i][idx], y1 = ry[i][idx], x2 = rx[j][idx], y2 = ry[j][idx];
                    float k = 0.86f + rnd.nextFloat() * 0.16f;
                    p.moveTo(x1, y1);
                    p.lineTo((x1 + x2) / 2 * k, (y1 + y2) / 2 * k);
                    p.lineTo(x2, y2);
                }
            }
        }
        return p;
    }

    private static void branch(Path p, Random rnd, float x, float y, float a, float L) {
        p.moveTo(x, y);
        int segs = 3;
        float seg = L / segs;
        for (int s = 0; s < segs; s++) {
            a += (rnd.nextFloat() - 0.5f) * 0.6f;
            x += cos(a) * seg;
            y += sin(a) * seg;
            p.lineTo(x, y);
        }
    }

    @Override
    boolean update(FxView w, float dt) {
        return age < life;
    }

    @Override
    void draw(Canvas c, FxView w) {
        float dp = w.dp;
        float a = age < 0.06f ? age / 0.06f : 1f;
        float fadeStart = life * 0.75f;
        if (age > fadeStart) a *= 1 - (age - fadeStart) / (life - fadeStart);
        if (a <= 0) return;
        c.save();
        c.translate(x, y);
        if (scorch) {
            Gfx.dot(c, 0, 0, r * 1.15f, 0xFF000000, Gfx.alpha(0.55f * a), false);
            Gfx.dot(c, 0, 0, r * 0.6f, 0xFF4E342E, Gfx.alpha(0.45f * a), false);
        } else {
            Gfx.dot(c, 0, 0, r * 0.4f, 0xFFFFFFFF, Gfx.alpha(0.1f * a), false);
        }
        Paint s = Gfx.stroke;
        float m = scorch ? 0.6f : 1f;
        // dark shadow under each crack line
        c.save();
        c.translate(dp * 0.9f, dp * 0.9f);
        s.setColor(0xFF000000);
        s.setAlpha(Gfx.alpha(0.32f * a * m));
        s.setStrokeWidth(2.4f * dp);
        c.drawPath(path, s);
        c.restore();
        // bright glassy edge
        s.setColor(0xFFFFFFFF);
        s.setAlpha(Gfx.alpha(0.6f * a * m));
        s.setStrokeWidth(1.5f * dp);
        c.drawPath(path, s);
        s.setAlpha(Gfx.alpha(0.95f * a * m));
        s.setStrokeWidth(0.6f * dp);
        c.drawPath(path, s);
        if (hole) {
            float hr = Math.max(3 * dp, r * 0.05f);
            Gfx.dot(c, 0, 0, hr * 3f, 0xFF000000, Gfx.alpha(0.65f * a), false);
            Paint f = Gfx.fill;
            f.setColor(0xFF0D0D0F);
            f.setAlpha(Gfx.alpha(0.92f * a));
            c.drawCircle(0, 0, hr, f);
            s.setColor(0xFFFFFFFF);
            s.setAlpha(Gfx.alpha(0.55f * a));
            s.setStrokeWidth(1.2f * dp);
            c.drawCircle(0, 0, hr * 1.5f, s);
        }
        c.restore();
    }
}
