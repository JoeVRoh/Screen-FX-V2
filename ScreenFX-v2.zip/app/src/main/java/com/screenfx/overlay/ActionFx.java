package com.screenfx.overlay;

import android.graphics.Canvas;

/** Runs a one-off action (a sound, a flash) after a delay, in step with delayed effects. */
final class ActionFx extends Fx {
    private final Runnable action;

    ActionFx(Runnable action, float delay) {
        this.action = action;
        this.delay = delay;
    }

    @Override
    boolean update(FxView w, float dt) {
        action.run();
        return false;
    }

    @Override
    void draw(Canvas c, FxView w) {
    }
}
