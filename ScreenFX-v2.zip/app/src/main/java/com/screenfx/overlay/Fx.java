package com.screenfx.overlay;

import android.graphics.Canvas;

/** Base class: something that animates for a while, optionally after a delay. */
abstract class Fx {
    float delay, age, life = 1f;

    final boolean step(FxView w, float dt) {
        if (delay > 0) {
            delay -= dt;
            return true;
        }
        age += dt;
        return update(w, dt);
    }

    final void render(Canvas c, FxView w) {
        if (delay <= 0) draw(c, w);
    }

    /** @return false when finished. */
    abstract boolean update(FxView w, float dt);

    abstract void draw(Canvas c, FxView w);

    static float cos(float a) {
        return (float) Math.cos(a);
    }

    static float sin(float a) {
        return (float) Math.sin(a);
    }

    static float easeOut(float t) {
        float u = 1 - Math.min(1, Math.max(0, t));
        return 1 - u * u * u;
    }
}
