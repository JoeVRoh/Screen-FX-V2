package com.screenfx.overlay;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;

import java.util.Random;

/** All sound effects, loaded once into a SoundPool. Sounds are synthesized by tools/make_sounds.py. */
final class Sfx {
    static final int POP = 0, WHOOSH = 1, BOOM = 2, BIG_BOOM = 3, SHOT = 4, CHIME = 5, DROP = 6, PUFF = 7,
            THUNDER = 8, FUSE = 9, LASER = 10, SPLAT = 11, BLING = 12, WHISTLE = 13, BANG = 14, CRACKLE = 15,
            FART_SHORT = 16, FART_CLASSIC = 17, FART_SQUEAK = 18, FART_WET = 19, FART_PFFT = 20,
            FART_LONG = 21, FART_RIPPLE = 22;

    private static final int[] RES = {
            R.raw.pop, R.raw.whoosh, R.raw.boom, R.raw.big_boom, R.raw.shot, R.raw.chime, R.raw.drop, R.raw.puff,
            R.raw.thunder, R.raw.fuse, R.raw.laser, R.raw.splat, R.raw.bling, R.raw.whistle, R.raw.bang, R.raw.crackle,
            R.raw.fart_short, R.raw.fart_classic, R.raw.fart_squeak, R.raw.fart_wet, R.raw.fart_pfft,
            R.raw.fart_long, R.raw.fart_ripple,
    };
    private static final int[] TAP_FARTS = {FART_SHORT, FART_CLASSIC, FART_SQUEAK, FART_WET, FART_PFFT};

    private static SoundPool pool;
    private static int[] ids;
    private static final Random rnd = new Random();

    private Sfx() {
    }

    static void init(Context c) {
        if (pool != null) return;
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        pool = new SoundPool.Builder().setMaxStreams(12).setAudioAttributes(aa).build();
        ids = new int[RES.length];
        Context app = c.getApplicationContext();
        for (int i = 0; i < RES.length; i++) ids[i] = pool.load(app, RES[i], 1);
    }

    static void play(Config cfg, int sound, float volume) {
        if (pool == null || !cfg.sound) return;
        float v = Math.min(1f, volume * cfg.volumePct / 100f);
        if (v <= 0.01f) return;
        float rate = 0.92f + rnd.nextFloat() * 0.16f;
        pool.play(ids[sound], v, v, 1, 0, rate);
    }

    static int randomFart() {
        return TAP_FARTS[rnd.nextInt(TAP_FARTS.length)];
    }
}
