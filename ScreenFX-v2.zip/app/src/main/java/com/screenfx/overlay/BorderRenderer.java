package com.screenfx.overlay;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.SweepGradient;

import java.util.ArrayList;
import java.util.Random;

/** Draws the animated frame around the whole screen. */
final class BorderRenderer {
    private final FxView v;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Matrix m = new Matrix();
    private SweepGradient sweep;
    private final ParticleFx parts = new ParticleFx();
    private final ArrayList<Fx> bolts = new ArrayList<>();
    private final Random rnd = new Random();
    private final float[] pt = new float[4];
    private float phase, emitAcc, boltTimer = 0.4f, boltGlow;
    // rounded-rect geometry used for perimeter math
    private float l, t, r, b, rad;

    BorderRenderer(FxView v) {
        this.v = v;
        p.setStyle(Paint.Style.STROKE);
        parts.keepAlive = true;
    }

    void reset() {
        sweep = null;
        parts.ps.clear();
        bolts.clear();
    }

    void draw(Canvas c, float dt) {
        Config cfg = v.cfg;
        if (cfg.border == Config.B_OFF) return;
        int w = v.getWidth(), h = v.getHeight();
        if (w == 0 || h == 0) return;
        float dp = v.dp;
        float bw = Math.max(1f, cfg.borderWidthDp * dp);
        float A = cfg.borderAlphaPct / 100f;
        float spd = cfg.borderSpeedPct / 100f;
        phase += dt * spd;
        int[] pal = cfg.palette();

        setGeometry(w, h, bw / 2, cfg.cornerDp * dp);
        p.setShader(null);

        switch (cfg.border) {
            case Config.B_GLOW: {
                float pulse = 0.65f + 0.35f * Fx.sin(phase * 3.2f);
                glow(c, Gfx.cycle(pal, phase * 0.35f), bw * (0.8f + 0.4f * pulse), A * pulse);
                break;
            }
            case Config.B_RAINBOW: {
                if (sweep == null) {
                    int[] cols = new int[pal.length + 1];
                    System.arraycopy(pal, 0, cols, 0, pal.length);
                    cols[pal.length] = pal[0];
                    sweep = new SweepGradient(w / 2f, h / 2f, cols, null);
                }
                m.setRotate(phase * 90f, w / 2f, h / 2f);
                sweep.setLocalMatrix(m);
                p.setShader(sweep);
                glow(c, 0xFFFFFFFF, bw, A);
                p.setShader(null);
                break;
            }
            case Config.B_MARQUEE: {
                glow(c, pal[0], bw * 0.5f, A * 0.25f);
                setGeometry(w, h, bw * 1.1f, cfg.cornerDp * dp);
                float spacing = Math.max(18 * dp, bw * 2.8f);
                float total = perimeter();
                int n = Math.max(4, (int) (total / spacing));
                float gap = total / n;
                int shift = (int) (phase * 7);
                Paint f = Gfx.fill;
                for (int i = 0; i < n; i++) {
                    point(i * gap, pt);
                    int col = pal[i % pal.length];
                    boolean on = ((i + shift) % 3) == 0;
                    Gfx.dot(c, pt[0], pt[1], bw * (on ? 2.4f : 1.4f), col, Gfx.alpha(A * (on ? 1f : 0.3f)), true);
                    f.setColor(on ? Gfx.lerp(col, 0xFFFFFFFF, 0.5f) : col);
                    f.setAlpha(Gfx.alpha(A * (on ? 1f : 0.45f)));
                    c.drawCircle(pt[0], pt[1], Math.max(1.5f * dp, bw * 0.45f), f);
                }
                break;
            }
            case Config.B_SPARKLE: {
                glow(c, Gfx.cycle(pal, phase * 0.2f), bw * 0.6f, A * 0.45f);
                float total = perimeter();
                emitAcc += dt * spd * 45 * (total / (2400 * dp));
                while (emitAcc >= 1 && parts.ps.size() < 250) {
                    emitAcc -= 1;
                    point(rnd.nextFloat() * total, pt);
                    float in = rnd.nextFloat() * bw * 2.5f;
                    Particle q = parts.add(Particle.STAR, pt[0] + pt[2] * in, pt[1] + pt[3] * in,
                            pt[2] * 18 * dp, pt[3] * 18 * dp, 0.6f + rnd.nextFloat() * 0.8f,
                            (4 + rnd.nextFloat() * 6) * dp + bw * 0.3f, pal[rnd.nextInt(pal.length)]);
                    q.phase = rnd.nextFloat() * 6;
                    q.rot = rnd.nextFloat() * 90;
                }
                if (emitAcc > 5) emitAcc = 0;
                break;
            }
            case Config.B_FLAMES: {
                glow(c, pal[pal.length - 1], bw * 0.7f, A * 0.35f);
                float total = perimeter();
                emitAcc += dt * spd * total / (9 * dp);
                while (emitAcc >= 1 && parts.ps.size() < 450) {
                    emitAcc -= 1;
                    point(rnd.nextFloat() * total, pt);
                    float sp = (50 + rnd.nextFloat() * 120) * dp * (0.6f + 0.4f * spd);
                    Particle q = parts.add(Particle.FLAME, pt[0], pt[1],
                            pt[2] * sp + (rnd.nextFloat() - 0.5f) * 30 * dp, pt[3] * sp - 40 * dp,
                            0.35f + rnd.nextFloat() * 0.45f, bw * (1.2f + rnd.nextFloat() * 1.4f) + 4 * dp, pal[0]);
                    q.color2 = pal[pal.length - 1];
                    q.grow = -bw * 1.2f;
                    q.add = true;
                }
                if (emitAcc > 5) emitAcc = 0;
                break;
            }
            case Config.B_LIGHTNING: {
                boltGlow = Math.max(0, boltGlow - dt * 3);
                float flicker = 0.85f + 0.15f * rnd.nextFloat();
                glow(c, pal[1 % pal.length], bw * 0.6f, A * (0.3f + 0.5f * boltGlow) * flicker);
                boltTimer -= dt * spd;
                if (boltTimer <= 0) {
                    boltTimer = 0.5f + rnd.nextFloat() * 1.8f;
                    float total = perimeter();
                    float start = rnd.nextFloat() * total;
                    float len = (250 + rnd.nextFloat() * 450) * dp;
                    int steps = Math.max(4, (int) (len / (16 * dp)));
                    Path bp = new Path();
                    for (int k = 0; k <= steps; k++) {
                        point(start + k * len / steps, pt);
                        float jit = (rnd.nextFloat() - 0.25f) * (bw * 2f + 10 * dp);
                        float x = pt[0] + pt[2] * jit, y = pt[1] + pt[3] * jit;
                        if (k == 0) bp.moveTo(x, y);
                        else bp.lineTo(x, y);
                    }
                    bolts.add(new BoltFx(bp, pal[rnd.nextInt(pal.length)], 0.6f + bw / (20 * dp), 0.4f));
                    boltGlow = 1f;
                }
                break;
            }
            case Config.B_GAS: {
                glow(c, pal[pal.length - 1], bw * 0.6f, A * 0.25f);
                float total = perimeter();
                emitAcc += dt * spd * total / (45 * dp);
                while (emitAcc >= 1 && parts.ps.size() < 180) {
                    emitAcc -= 1;
                    point(rnd.nextFloat() * total, pt);
                    float sp = (10 + rnd.nextFloat() * 30) * dp;
                    float in = rnd.nextFloat() * bw;
                    Particle q = parts.add(Particle.SMOKE, pt[0] + pt[2] * in, pt[1] + pt[3] * in,
                            pt[2] * sp + (rnd.nextFloat() - 0.5f) * 20 * dp, pt[3] * sp - 8 * dp,
                            2.2f + rnd.nextFloat() * 2f, (20 + rnd.nextFloat() * 20) * dp + bw * 1.5f,
                            pal[rnd.nextInt(pal.length)]);
                    q.grow = (8 + rnd.nextFloat() * 10) * dp;
                    q.baseAlpha = 0.45f;
                    q.drag = 0.3f;
                }
                if (emitAcc > 5) emitAcc = 0;
                break;
            }
            default:
                break;
        }

        parts.step(v, dt);
        for (int i = bolts.size() - 1; i >= 0; i--) if (!bolts.get(i).step(v, dt)) bolts.remove(i);
        if (!parts.ps.isEmpty() || !bolts.isEmpty()) {
            boolean layer = A < 0.99f;
            int save = layer ? c.saveLayerAlpha(0, 0, w, h, Gfx.alpha(A)) : -1;
            parts.render(c, v);
            for (int i = 0; i < bolts.size(); i++) bolts.get(i).render(c, v);
            if (layer) c.restoreToCount(save);
        }
    }

    /** Layered strokes to fake a soft glow (BlurMaskFilter is slow on overlays). */
    private void glow(Canvas c, int color, float width, float alpha) {
        for (int k = 0; k < 4; k++) {
            p.setStrokeWidth(width * (1 + k * 1.1f));
            p.setColor(color);
            p.setAlpha(Gfx.alpha(alpha / (1 + k * 1.7f)));
            c.drawRoundRect(rect, rad, rad, p);
        }
    }

    private void setGeometry(int w, int h, float inset, float corner) {
        l = inset;
        t = inset;
        r = w - inset;
        b = h - inset;
        rad = Math.max(0, Math.min(corner, Math.min(r - l, b - t) / 2));
        rect.set(l, t, r, b);
    }

    private float perimeter() {
        return 2 * (r - l - 2 * rad) + 2 * (b - t - 2 * rad) + (float) (2 * Math.PI * rad);
    }

    /** Point at distance d along the rounded rect, clockwise from top-left. out = x, y, inward normal x, y. */
    private void point(float d, float[] out) {
        float W = r - l - 2 * rad, H = b - t - 2 * rad, arc = (float) (Math.PI / 2 * rad);
        float total = 2 * W + 2 * H + 4 * arc;
        d %= total;
        if (d < 0) d += total;
        if (d < W) { set(out, l + rad + d, t, 0, 1); return; }
        d -= W;
        if (d < arc) { arcPt(out, r - rad, t + rad, -90 + d / arc * 90); return; }
        d -= arc;
        if (d < H) { set(out, r, t + rad + d, -1, 0); return; }
        d -= H;
        if (d < arc) { arcPt(out, r - rad, b - rad, d / arc * 90); return; }
        d -= arc;
        if (d < W) { set(out, r - rad - d, b, 0, -1); return; }
        d -= W;
        if (d < arc) { arcPt(out, l + rad, b - rad, 90 + d / arc * 90); return; }
        d -= arc;
        if (d < H) { set(out, l, b - rad - d, 1, 0); return; }
        d -= H;
        arcPt(out, l + rad, t + rad, 180 + Math.min(1, d / Math.max(arc, 0.001f)) * 90);
    }

    private static void set(float[] o, float x, float y, float nx, float ny) {
        o[0] = x;
        o[1] = y;
        o[2] = nx;
        o[3] = ny;
    }

    private void arcPt(float[] o, float cx, float cy, float deg) {
        float a = (float) Math.toRadians(deg);
        float ca = Fx.cos(a), sa = Fx.sin(a);
        set(o, cx + ca * rad, cy + sa * rad, -ca, -sa);
    }
}
