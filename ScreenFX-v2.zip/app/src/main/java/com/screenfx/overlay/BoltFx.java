package com.screenfx.overlay;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

import java.util.Random;

/** A flickering lightning bolt along a path. */
final class BoltFx extends Fx {
    final Path path;
    final int color;
    final float scale;
    private final Random rnd = new Random();

    BoltFx(Path path, int color, float scale, float life) {
        this.path = path;
        this.color = color;
        this.scale = scale;
        this.life = life;
    }

    static Path jagged(Random r, float x0, float y0, float x1, float y1, float amp) {
        Path p = new Path();
        p.moveTo(x0, y0);
        int steps = 9;
        float dx = x1 - x0, dy = y1 - y0;
        float len = (float) Math.hypot(dx, dy);
        float nx = len == 0 ? 0 : -dy / len, ny = len == 0 ? 0 : dx / len;
        float bx = x0, by = y0;
        for (int i = 1; i <= steps; i++) {
            float t = i / (float) steps;
            float off = i == steps ? 0 : (r.nextFloat() - 0.5f) * 2 * amp;
            float px = x0 + dx * t + nx * off, py = y0 + dy * t + ny * off;
            p.lineTo(px, py);
            if (i == steps / 2) {
                bx = px;
                by = py;
            }
        }
        // one side branch
        p.moveTo(bx, by);
        float ba = (float) Math.atan2(dy, dx) + (r.nextBoolean() ? 0.6f : -0.6f);
        float bl = len * 0.3f;
        for (int i = 1; i <= 4; i++) {
            bx += cos(ba) * bl / 4 + (r.nextFloat() - 0.5f) * amp;
            by += sin(ba) * bl / 4 + (r.nextFloat() - 0.5f) * amp;
            p.lineTo(bx, by);
        }
        return p;
    }

    @Override
    boolean update(FxView w, float dt) {
        return age < life;
    }

    @Override
    void draw(Canvas c, FxView w) {
        float a = (1 - age / life) * (0.55f + 0.45f * rnd.nextFloat());
        Paint s = Gfx.stroke;
        float dp = w.dp * scale;
        s.setColor(color);
        s.setAlpha(Gfx.alpha(a * 0.22f));
        s.setStrokeWidth(10 * dp);
        c.drawPath(path, s);
        s.setAlpha(Gfx.alpha(a * 0.5f));
        s.setStrokeWidth(4.5f * dp);
        c.drawPath(path, s);
        s.setColor(0xFFFFFFFF);
        s.setAlpha(Gfx.alpha(a));
        s.setStrokeWidth(1.8f * dp);
        c.drawPath(path, s);
    }
}
