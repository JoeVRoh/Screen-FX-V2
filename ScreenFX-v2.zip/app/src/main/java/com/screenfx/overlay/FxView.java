package com.screenfx.overlay;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import java.util.ArrayList;
import java.util.Random;

/**
 * Renders the border and all touch effects. Used full-screen in the overlay window
 * and as the in-app preview pad.
 */
public class FxView extends View implements SharedPreferences.OnSharedPreferenceChangeListener {
    public static final int TAP = 0, HOLD = 1, SWIPE = 2;

    /** Receives each finished one-finger gesture in screen coordinates, so it can be replayed to the app below. */
    public interface GestureSink {
        void onGesture(float[] xs, float[] ys, int n, long durationMs);
    }

    Config cfg;
    final float dp;
    final Random rnd = new Random();

    private final ArrayList<Fx> decals = new ArrayList<>();
    private final ArrayList<Fx> effects = new ArrayList<>();
    private final ArrayList<Fx> pending = new ArrayList<>();
    private final ParticleFx touchTrail = new ParticleFx();
    private final BorderRenderer border;
    private long lastNanos;
    private float shake, flash;
    private boolean touchEnabled = true;
    private final float slop;

    // gesture tracking
    private float downX, downY, lastX, lastY, trailDist, pathDist;
    private boolean held, swiping, tracking;
    private static final int H = 48;
    private final float[] hx = new float[H], hy = new float[H];
    private final long[] ht = new long[H];
    private int hn;
    private static final int MAX_PATH = 60;
    private final float[] path = new float[MAX_PATH * 2];
    private int pn;
    // raw screen-coordinate path for replaying the gesture
    private static final int MAX_RAW = 200;
    private final float[] rawX = new float[MAX_RAW], rawY = new float[MAX_RAW];
    private int rawN;
    private long downTime;
    private GestureSink sink;

    private final Runnable longPress = new Runnable() {
        @Override
        public void run() {
            if (!tracking || swiping) return;
            held = true;
            Spawner.spawn(FxView.this, cfg.hold, HOLD, downX, downY, 0, 0, null, 0);
            buzz(true);
            kick();
        }
    };

    public FxView(Context ctx) {
        super(ctx);
        Gfx.init();
        Sfx.init(ctx);
        dp = getResources().getDisplayMetrics().density;
        slop = ViewConfiguration.get(ctx).getScaledTouchSlop();
        cfg = Config.load(ctx);
        border = new BorderRenderer(this);
        touchTrail.keepAlive = true;
    }

    public void setTouchEnabled(boolean on) {
        touchEnabled = on;
        if (!on) {
            removeCallbacks(longPress);
            tracking = false;
        }
    }

    public void setGestureSink(GestureSink s) {
        sink = s;
    }

    public void clearAll() {
        decals.clear();
        effects.clear();
        pending.clear();
        touchTrail.ps.clear();
        flash = 0;
        shake = 0;
        invalidate();
    }

    void add(Fx f) {
        pending.add(f);
        kick();
    }

    void addDecal(Fx f) {
        decals.add(f);
        while (decals.size() > 48) decals.remove(0);
        kick();
    }

    void shake(float px) {
        if (cfg.flashShake) shake = Math.max(shake, px);
    }

    void flash(float a) {
        if (cfg.flashShake) flash = Math.max(flash, a);
    }

    void sound(final int id, float delay, final float vol) {
        if (delay <= 0) {
            Sfx.play(cfg, id, vol);
        } else {
            add(new ActionFx(new Runnable() {
                @Override
                public void run() {
                    Sfx.play(cfg, id, vol);
                }
            }, delay));
        }
    }

    void kick() {
        postInvalidateOnAnimation();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        Config.prefs(getContext()).registerOnSharedPreferenceChangeListener(this);
        cfg = Config.load(getContext());
        border.reset();
        kick();
    }

    @Override
    protected void onDetachedFromWindow() {
        Config.prefs(getContext()).unregisterOnSharedPreferenceChangeListener(this);
        removeCallbacks(longPress);
        super.onDetachedFromWindow();
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
        cfg = Config.load(getContext());
        border.reset();
        kick();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        border.reset();
    }

    @Override
    protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        float dt = lastNanos == 0 ? 1 / 60f : Math.min(0.05f, (now - lastNanos) / 1e9f);
        lastNanos = now;

        step(decals, dt);
        step(effects, dt);
        touchTrail.step(this, dt);
        if (!pending.isEmpty()) {
            effects.addAll(pending);
            pending.clear();
        }

        int save = c.save();
        if (shake > 0.5f) {
            c.translate((rnd.nextFloat() * 2 - 1) * shake, (rnd.nextFloat() * 2 - 1) * shake);
            shake = Math.max(0, shake * (1 - dt * 9) - dt * 2 * dp);
        } else {
            shake = 0;
        }
        for (int i = 0; i < decals.size(); i++) decals.get(i).render(c, this);
        for (int i = 0; i < effects.size(); i++) effects.get(i).render(c, this);
        touchTrail.render(c, this);
        c.restoreToCount(save);

        border.draw(c, dt);

        if (flash > 0.01f) {
            c.drawColor(Color.argb(Gfx.alpha(flash), 255, 255, 255));
            flash = Math.max(0, flash - dt * 3.5f);
        }

        boolean busy = !decals.isEmpty() || !effects.isEmpty() || !pending.isEmpty() || !touchTrail.ps.isEmpty()
                || cfg.border != Config.B_OFF || flash > 0 || shake > 0;
        if (busy) postInvalidateOnAnimation();
        else lastNanos = 0;
    }

    private void step(ArrayList<Fx> list, float dt) {
        for (int i = list.size() - 1; i >= 0; i--) {
            if (i >= list.size()) continue;
            if (!list.get(i).step(this, dt)) list.remove(i);
        }
    }

    // ---------------- touch ----------------

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (!touchEnabled) return false;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                downX = lastX = e.getX();
                downY = lastY = e.getY();
                held = false;
                swiping = false;
                tracking = true;
                hn = 0;
                pn = 0;
                pathDist = 0;
                trailDist = 0;
                record(downX, downY, e.getEventTime());
                addPath(downX, downY);
                downTime = e.getEventTime();
                rawN = 0;
                addRaw(e.getRawX(), e.getRawY());
                postDelayed(longPress, 380);
                return true;
            }
            case MotionEvent.ACTION_POINTER_DOWN: {
                int i = e.getActionIndex();
                Spawner.spawn(this, cfg.tap, TAP, e.getX(i), e.getY(i), 0, 0, null, 0);
                buzz(false);
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (!tracking) return true;
                float x = e.getX(), y = e.getY();
                addRaw(e.getRawX(), e.getRawY());
                if (!swiping && !held && Math.hypot(x - downX, y - downY) > slop * 1.5f) {
                    swiping = true;
                    removeCallbacks(longPress);
                }
                if (swiping) {
                    record(x, y, e.getEventTime());
                    float d = (float) Math.hypot(x - lastX, y - lastY);
                    pathDist += d;
                    trailDist += d;
                    if (pathDist >= 24 * dp) {
                        addPath(x, y);
                        pathDist = 0;
                    }
                    if (trailDist >= 10 * dp) {
                        trailDist = 0;
                        emitTrail(x, y);
                    }
                    kick();
                }
                lastX = x;
                lastY = y;
                return true;
            }
            case MotionEvent.ACTION_UP: {
                removeCallbacks(longPress);
                float x = e.getX(), y = e.getY();
                if (tracking && !held) {
                    if (swiping) {
                        record(x, y, e.getEventTime());
                        addPath(x, y);
                        float[] v = velocity();
                        Spawner.spawn(this, cfg.swipe, SWIPE, x, y, v[0], v[1], path, pn);
                    } else {
                        Spawner.spawn(this, cfg.tap, TAP, x, y, 0, 0, null, 0);
                    }
                    buzz(false);
                }
                if (tracking && sink != null) {
                    addRaw(e.getRawX(), e.getRawY());
                    float[] xs = new float[rawN], ys = new float[rawN];
                    System.arraycopy(rawX, 0, xs, 0, rawN);
                    System.arraycopy(rawY, 0, ys, 0, rawN);
                    // a quick tap replays at one point; holds and swipes replay the whole path (so drags work too)
                    int n = (swiping || held) ? rawN : 1;
                    sink.onGesture(xs, ys, n, Math.max(1, e.getEventTime() - downTime));
                }
                tracking = false;
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                removeCallbacks(longPress);
                tracking = false;
                return true;
            default:
                return true;
        }
    }

    private void record(float x, float y, long t) {
        if (hn == H) {
            System.arraycopy(hx, H / 2, hx, 0, H / 2);
            System.arraycopy(hy, H / 2, hy, 0, H / 2);
            System.arraycopy(ht, H / 2, ht, 0, H / 2);
            hn = H / 2;
        }
        hx[hn] = x;
        hy[hn] = y;
        ht[hn] = t;
        hn++;
    }

    private void addRaw(float x, float y) {
        if (rawN == MAX_RAW) {
            // keep every other point so long gestures still fit
            for (int i = 0; i < MAX_RAW / 2; i++) {
                rawX[i] = rawX[i * 2];
                rawY[i] = rawY[i * 2];
            }
            rawN = MAX_RAW / 2;
        }
        rawX[rawN] = x;
        rawY[rawN] = y;
        rawN++;
    }

    private void addPath(float x, float y) {
        if (pn < MAX_PATH) {
            path[2 * pn] = x;
            path[2 * pn + 1] = y;
            pn++;
        } else {
            path[2 * (MAX_PATH - 1)] = x;
            path[2 * (MAX_PATH - 1) + 1] = y;
        }
    }

    /** Pixels per second over the last ~80 ms of the swipe. */
    private float[] velocity() {
        if (hn < 2) return new float[]{0, 0};
        int end = hn - 1, i = end;
        while (i > 0 && ht[end] - ht[i] < 80) i--;
        float secs = (ht[end] - ht[i]) / 1000f;
        if (secs <= 0) return new float[]{0, 0};
        return new float[]{(hx[end] - hx[i]) / secs, (hy[end] - hy[i]) / secs};
    }

    private void emitTrail(float x, float y) {
        if (touchTrail.ps.size() > 300) return;
        int[] pal = cfg.palette();
        Particle p = touchTrail.add(Particle.DOT, x, y, (rnd.nextFloat() - 0.5f) * 40 * dp, (rnd.nextFloat() - 0.5f) * 40 * dp,
                0.45f, (8 + rnd.nextFloat() * 6) * dp, pal[rnd.nextInt(pal.length)]);
        p.add = true;
        p.grow = -12 * dp;
    }

    private void buzz(boolean strong) {
        if (cfg.haptics) {
            performHapticFeedback(strong ? HapticFeedbackConstants.LONG_PRESS : HapticFeedbackConstants.VIRTUAL_KEY);
        }
    }
}
