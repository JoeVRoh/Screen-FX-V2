package com.screenfx.overlay;

import android.graphics.Canvas;

import java.util.Random;

/** A rocket that whistles up from the bottom of the screen and bursts at the target. */
final class FireworkFx extends Fx {
    float x, y;
    final float tx, ty, scale, speed;
    final ParticleFx trail;

    FireworkFx(FxView w, ParticleFx trail, float tx, float ty, float scale) {
        this.trail = trail;
        this.tx = tx;
        this.ty = ty;
        this.scale = scale;
        this.x = tx + (w.rnd.nextFloat() - 0.5f) * 60 * w.dp;
        this.y = w.getHeight() + 10 * w.dp;
        this.speed = 1500 * w.dp;
        this.life = 5f;
        trail.keepAlive = true;
    }

    @Override
    boolean update(FxView w, float dt) {
        float dp = w.dp;
        Random r = w.rnd;
        if (age < dt * 1.5f) w.sound(Sfx.WHISTLE, 0, 0.55f);
        float dx = tx - x, dy = ty - y;
        float dist = (float) Math.hypot(dx, dy);
        float step = speed * dt;
        if (dist <= step || age > life) {
            burst(w, tx, ty, scale);
            trail.keepAlive = false;
            return false;
        }
        x += dx / dist * step;
        y += dy / dist * step;
        for (int k = 0; k < 2; k++) {
            Particle p = trail.add(Particle.SPARK, x, y, (r.nextFloat() - 0.5f) * 60 * dp, 120 * dp,
                    0.25f + r.nextFloat() * 0.25f, 2 * dp, 0xFFFFD180);
            p.gravity = 300 * dp;
        }
        return true;
    }

    static void burst(FxView w, float x, float y, float s) {
        float dp = w.dp;
        Random r = w.rnd;
        int[] pal = w.cfg.palette();
        int c1 = pal[r.nextInt(pal.length)], c2 = pal[r.nextInt(pal.length)];
        ParticleFx p = new ParticleFx();
        Particle core = p.add(Particle.DOT, x, y, 0, 0, 0.15f, 55 * dp * s, 0xFFFFFFFF);
        core.add = true;
        for (int i = 0; i < 70; i++) {
            float a = i * Gfx.TAU / 70 + r.nextFloat() * 0.08f, sp = (200 + r.nextFloat() * 230) * dp * s;
            Particle q = p.add(Particle.SPARK, x, y, cos(a) * sp, sin(a) * sp, 1.1f + r.nextFloat() * 0.6f,
                    2.6f * dp, (i % 2 == 0) ? c1 : c2);
            q.gravity = 220 * dp;
            q.drag = 1.4f;
        }
        for (int i = 0; i < 30; i++) {
            float a = r.nextFloat() * Gfx.TAU, sp = r.nextFloat() * 260 * dp * s;
            Particle q = p.add(Particle.STAR, x, y, cos(a) * sp, sin(a) * sp, 1.2f + r.nextFloat() * 0.6f,
                    (3 + r.nextFloat() * 3) * dp, Gfx.lerp(c1, 0xFFFFFFFF, 0.4f));
            q.gravity = 160 * dp;
            q.drag = 1.6f;
            q.phase = r.nextFloat() * 6;
        }
        w.add(p);
        ParticleFx crackle = new ParticleFx();
        crackle.delay = 0.45f;
        for (int i = 0; i < 26; i++) {
            float a = r.nextFloat() * Gfx.TAU, d = (40 + r.nextFloat() * 120) * dp * s;
            Particle q = crackle.add(Particle.DOT, x + cos(a) * d, y + sin(a) * d + 30 * dp, 0, 40 * dp,
                    0.15f + r.nextFloat() * 0.3f, (4 + r.nextFloat() * 4) * dp, 0xFFFFFFFF);
            q.add = true;
        }
        w.add(crackle);
        RingFx ring = new RingFx(x, y, 90 * dp * s, c1, 4 * dp, 0.5f);
        w.add(ring);
        w.sound(Sfx.BANG, 0, 0.9f);
        w.sound(Sfx.CRACKLE, 0.4f, 0.7f);
    }

    @Override
    void draw(Canvas c, FxView w) {
        float dp = w.dp;
        Gfx.dot(c, x, y, 12 * dp, 0xFFFFC46B, 230, true);
        Gfx.dot(c, x, y, 4 * dp, 0xFFFFFFFF, 255, true);
    }
}
