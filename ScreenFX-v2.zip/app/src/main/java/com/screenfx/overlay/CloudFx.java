package com.screenfx.overlay;

import android.graphics.Canvas;

import java.util.Random;

/** Fluffy cloud. Storm clouds rain and throw lightning. */
final class CloudFx extends Fx {
    float x, y, vx, vy;
    final float scale;
    final boolean storm;
    static final int N = 8;
    final float[] px = new float[N], py = new float[N], pr = new float[N];
    final int color, shade;
    private ParticleFx rain;
    private float rainAcc, boltTimer = 0.35f;

    CloudFx(FxView w, float x, float y, float vx, float vy, float scale, boolean storm, float life) {
        this.x = x;
        this.y = y;
        this.vx = vx;
        this.vy = vy;
        this.scale = scale;
        this.storm = storm;
        this.life = life;
        float dp = w.dp;
        Random r = w.rnd;
        for (int i = 0; i < N; i++) {
            px[i] = (r.nextFloat() - 0.5f) * 100 * dp;
            py[i] = (r.nextFloat() - 0.5f) * 26 * dp - (1 - Math.abs(px[i]) / (50 * dp)) * 18 * dp;
            pr[i] = (24 + r.nextFloat() * 20) * dp;
        }
        int tint = w.cfg.palette()[0];
        color = storm ? 0xFF7A828E : Gfx.lerp(0xFFFFFFFF, tint, 0.12f);
        shade = storm ? 0xFF2E333B : 0xFF9AA4B4;
    }

    @Override
    boolean update(FxView w, float dt) {
        float dp = w.dp;
        float d = 1f / (1f + 1.4f * dt);
        vx *= d;
        vy *= d;
        x += vx * dt;
        y += vy * dt - 8 * dp * dt;
        if (storm && age < life - 0.6f) {
            if (rain == null) {
                rain = new ParticleFx();
                rain.keepAlive = true;
                w.add(rain);
            }
            rainAcc += dt * 70;
            while (rainAcc >= 1) {
                rainAcc -= 1;
                Particle p = rain.add(Particle.SPARK, x + (w.rnd.nextFloat() - 0.5f) * 110 * dp * scale,
                        y + 18 * dp * scale, -40 * dp, 950 * dp, 0.7f, 1.6f * dp, 0xFFB3E5FC);
                p.baseAlpha = 0.8f;
            }
            boltTimer -= dt;
            if (boltTimer <= 0) {
                boltTimer = 0.5f + w.rnd.nextFloat() * 0.8f;
                float bx = x + (w.rnd.nextFloat() - 0.5f) * 60 * dp * scale;
                w.add(new BoltFx(BoltFx.jagged(w.rnd, bx, y + 15 * dp * scale, bx + (w.rnd.nextFloat() - 0.5f) * 120 * dp,
                        y + (220 + w.rnd.nextFloat() * 160) * dp * scale, 16 * dp), 0xFFB388FF, scale, 0.35f));
                w.flash(0.18f);
                w.sound(Sfx.THUNDER, 0, 0.8f);
            }
        }
        boolean alive = age < life;
        if (!alive && rain != null) rain.keepAlive = false;
        if (storm && age >= life - 0.6f && rain != null) rain.keepAlive = false;
        return alive;
    }

    @Override
    void draw(Canvas c, FxView w) {
        float g = (0.7f + 0.45f * easeOut(age / (life * 0.6f))) * scale;
        float a = Math.min(1, age / 0.25f);
        if (age > life - 1f) a *= Math.max(0, life - age);
        for (int i = 0; i < N; i++)
            Gfx.dot(c, x + px[i] * g, y + py[i] * g + pr[i] * 0.3f * g, pr[i] * 1.35f * g, shade, Gfx.alpha(0.45f * a), false);
        for (int i = 0; i < N; i++)
            Gfx.dot(c, x + px[i] * g, y + py[i] * g, pr[i] * 1.4f * g, color, Gfx.alpha(0.92f * a), false);
    }
}
