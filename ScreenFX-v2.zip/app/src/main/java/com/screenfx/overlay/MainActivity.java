package com.screenfx.overlay;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/** Settings screen with a live preview pad. Built in code so the project has no layout XML to maintain. */
public class MainActivity extends Activity {
    private static final int BG = 0xFF0E0F14, CARD = 0xFF171922, TEXT = 0xFFF2F3F7, SUB = 0xFF9AA0AE,
            ACCENT = 0xFF7C5CFF, CHIP = 0xFF222533, CHIP_EDGE = 0xFF2E3242;

    private SharedPreferences prefs;
    private Config cfg;
    private float dp;
    private FxView preview;
    private TextView status, permBtn, startBtn, playBtn, helperStatus, helperBtn, appInfoBtn;
    private LinearLayout helperBox;
    private final ArrayList<Runnable> refreshers = new ArrayList<>();

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        dp = getResources().getDisplayMetrics().density;
        prefs = Config.prefs(this);
        cfg = Config.load(this);

        ScrollView root = new ScrollView(this);
        root.setBackgroundColor(BG);
        root.setFillViewport(true);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int pad = px(18);
        col.setPadding(pad, pad, pad, pad);
        root.addView(col, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                @Override
                public WindowInsets onApplyWindowInsets(View v, WindowInsets ins) {
                    Insets i = ins.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                    v.setPadding(i.left, i.top, i.right, i.bottom);
                    return ins;
                }
            });
        }

        // ---- header ----
        TextView title = text("ScreenFX", 30, TEXT, true);
        col.addView(title);
        TextView sub = text("Animated borders and touch effects over your whole screen.", 15, SUB, false);
        sub.setPadding(0, px(2), 0, px(14));
        col.addView(sub);

        // ---- preview pad ----
        FrameLayout box = new FrameLayout(this);
        GradientDrawable boxBg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xFF1C2140, 0xFF0A0B10});
        boxBg.setCornerRadius(px(22));
        box.setBackground(boxBg);
        box.setClipToOutline(true);
        preview = new FxView(this);
        box.addView(preview, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        TextView hint = text("Try it here: tap  •  hold  •  swipe", 14, 0x80FFFFFF, false);
        hint.setGravity(Gravity.CENTER);
        box.addView(hint, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        col.addView(box, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(300)));

        TextView clear = text("Clear preview", 14, ACCENT, true);
        clear.setGravity(Gravity.END);
        clear.setPadding(0, px(8), px(4), px(4));
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preview.clearAll();
            }
        });
        col.addView(clear);

        // ---- overlay controls ----
        LinearLayout card = card();
        status = text("", 15, TEXT, false);
        card.addView(status);
        permBtn = button("Allow \"Display over other apps\"", true);
        permBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            }
        });
        card.addView(permBtn, buttonLp());
        startBtn = button("Start overlay", true);
        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleOverlay();
            }
        });
        card.addView(startBtn, buttonLp());
        playBtn = button("Play mode", false);
        playBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startService(new Intent(MainActivity.this, OverlayService.class).setAction(OverlayService.ACTION_TOGGLE));
                OverlayService.playMode = !OverlayService.playMode;
                refreshControls();
            }
        });
        card.addView(playBtn, buttonLp());
        col.addView(card, cardLp());

        // ---- templates ----
        col.addView(section("Templates"));
        col.addView(note("Pick a starting point, then tweak anything below."));
        String[] tNames = new String[Config.TEMPLATES.length];
        for (int i = 0; i < tNames.length; i++) tNames[i] = Config.TEMPLATES[i].name;
        col.addView(chips(tNames, null, new IntSupplier() {
            @Override
            public int getAsInt() {
                return cfg.template;
            }
        }, new IntConsumer() {
            @Override
            public void accept(int i) {
                Config.applyTemplate(MainActivity.this, i);
            }
        }));

        // ---- theme ----
        col.addView(section("Color theme"));
        col.addView(chips(Config.THEME_NAMES, Config.PALETTES, getter(Config.K_THEME), setter(Config.K_THEME)));

        // ---- border ----
        col.addView(section("Screen border"));
        col.addView(chips(Config.BORDER_NAMES, null, getter(Config.K_BORDER), setter(Config.K_BORDER)));
        col.addView(slider("Thickness", Config.K_BORDER_WIDTH, 2, 40, cfg.borderWidthDp, " dp"));
        col.addView(slider("Speed", Config.K_BORDER_SPEED, 20, 300, cfg.borderSpeedPct, "%"));
        col.addView(slider("Opacity", Config.K_BORDER_ALPHA, 20, 100, cfg.borderAlphaPct, "%"));
        col.addView(slider("Corner rounding (match your screen)", Config.K_CORNER, 0, 80, cfg.cornerDp, " dp"));

        // ---- gestures ----
        col.addView(section("Gestures"));
        col.addView(label("Tap"));
        col.addView(chips(Config.EFFECT_NAMES, null, getter(Config.K_TAP), setter(Config.K_TAP)));
        col.addView(label("Hold"));
        col.addView(chips(Config.EFFECT_NAMES, null, getter(Config.K_HOLD), setter(Config.K_HOLD)));
        col.addView(label("Swipe"));
        col.addView(chips(Config.EFFECT_NAMES, null, getter(Config.K_SWIPE), setter(Config.K_SWIPE)));

        // ---- effect options ----
        col.addView(section("Effects"));
        col.addView(slider("Effect size", Config.K_SIZE, 50, 200, cfg.sizePct, "%"));
        col.addView(slider("Cracks and scorch marks last", Config.K_CRACK_SECONDS, 2, 60, cfg.crackSeconds, " s"));
        col.addView(toggle("Screen flash and shake (bombs, storms)", Config.K_FLASH, cfg.flashShake));
        col.addView(toggle("Haptic feedback", Config.K_HAPTICS, cfg.haptics));
        col.addView(toggle("Floating play button", Config.K_BUBBLE, cfg.bubble));
        col.addView(toggle("Sound effects", Config.K_SOUND, cfg.sound));
        col.addView(slider("Volume", Config.K_VOLUME, 0, 100, cfg.volumePct, "%"));

        // ---- play mode: keep taps working ----
        col.addView(section("Play mode"));
        Switch pass = new Switch(this);
        pass.setText("Taps still work in Play mode");
        pass.setTextColor(TEXT);
        pass.setTextSize(15);
        pass.setChecked(cfg.passTaps);
        pass.setPadding(0, px(10), 0, px(10));
        pass.setThumbTintList(ColorStateList.valueOf(ACCENT));
        pass.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean on) {
                prefs.edit().putBoolean(Config.K_PASS_TAPS, on).apply();
                cfg = Config.load(MainActivity.this);
                refreshControls();
            }
        });
        col.addView(pass);
        col.addView(note("Effects still appear, and each tap, hold and swipe is then passed on to the app underneath, so you can keep using your phone. Taps feel normal; swipes and scrolls happen just after you lift your finger. Two-finger gestures like pinch-zoom aren't passed on."));
        helperBox = card();
        helperStatus = text("", 14, TEXT, false);
        helperBox.addView(helperStatus);
        helperBtn = button("Turn on tap helper", true);
        helperBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showHelperDisclosure();
            }
        });
        helperBox.addView(helperBtn, buttonLp());
        appInfoBtn = button("Switch greyed out? Open App info", false);
        appInfoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
            }
        });
        helperBox.addView(appInfoBtn, buttonLp());
        col.addView(helperBox, cardLp());

        // ---- help ----
        col.addView(section("How it works"));
        col.addView(note("Android lets an overlay either pass touches through to your apps, or catch them, but not both at once. So ScreenFX has two modes:\n\n"
                + "• Normal use: the animated border stays on top while you use your phone as usual.\n"
                + "• Play mode: tap the floating button (or the notification) and every tap, hold and swipe on the screen creates effects. Tap the button again to get your phone back, or turn on \"Taps still work in Play mode\" above.\n\n"
                + "Long-press the floating button to come back to these settings. Stop the overlay any time from the notification."));

        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshControls();
    }

    private void showHelperDisclosure() {
        new AlertDialog.Builder(this)
                .setTitle("Turn on the tap helper")
                .setMessage("ScreenFX uses an Accessibility service only to pass your own taps, holds and swipes on to the app underneath while Play mode draws effects.\n\n"
                        + "It does not read what's on your screen, and it doesn't collect or share any data.\n\n"
                        + "On the next screen, open \"ScreenFX tap helper\" (it may be under \"Downloaded apps\") and switch it on.")
                .setPositiveButton("Continue", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                    }
                })
                .setNegativeButton("Not now", null)
                .show();
    }

    private void toggleOverlay() {
        Intent svc = new Intent(this, OverlayService.class);
        if (OverlayService.running) {
            stopService(svc);
            OverlayService.running = false;
            OverlayService.playMode = false;
        } else {
            if (!Settings.canDrawOverlays(this)) {
                permBtn.performClick();
                return;
            }
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
            }
            startForegroundService(svc);
            OverlayService.running = true;
        }
        refreshControls();
        startBtn.postDelayed(new Runnable() {
            @Override
            public void run() {
                refreshControls();
            }
        }, 400);
    }

    private void refreshControls() {
        boolean permitted = Settings.canDrawOverlays(this);
        boolean running = OverlayService.running;
        permBtn.setVisibility(permitted ? View.GONE : View.VISIBLE);
        startBtn.setVisibility(permitted ? View.VISIBLE : View.GONE);
        startBtn.setText(running ? "Stop overlay" : "Start overlay");
        playBtn.setVisibility(running ? View.VISIBLE : View.GONE);
        playBtn.setText(OverlayService.playMode ? "Play mode is ON (tap to use phone normally)" : "Turn on Play mode");
        boolean helperOn = TapHelperService.instance != null;
        helperBox.setVisibility(cfg.passTaps ? View.VISIBLE : View.GONE);
        helperBtn.setVisibility(helperOn ? View.GONE : View.VISIBLE);
        appInfoBtn.setVisibility(helperOn ? View.GONE : View.VISIBLE);
        helperStatus.setText(helperOn
                ? "Tap helper is on. In Play mode your taps will reach your apps."
                : "One more step: turn on the ScreenFX tap helper in Accessibility settings.\n\n"
                + "If its switch is greyed out (Android 13 and newer does this for apps installed outside the Play Store): "
                + "open App info, tap the ⋮ menu at the top right, choose \"Allow restricted settings\", then try again.");
        if (!permitted) {
            status.setText("Step 1: allow ScreenFX to display over other apps. Android will open a settings page; switch ScreenFX on, then come back.");
        } else if (!running) {
            status.setText("Ready. Start the overlay to put your border and effects on top of everything.");
        } else {
            status.setText(OverlayService.playMode
                    ? "Overlay running in Play mode: touches anywhere create effects."
                    : "Overlay running. Your phone works normally; turn on Play mode for touch effects.");
        }
    }

    // ---------------- UI helpers ----------------

    private int px(float v) {
        return (int) (v * dp + 0.5f);
    }

    private IntSupplier getter(final String key) {
        return new IntSupplier() {
            @Override
            public int getAsInt() {
                return prefs.getInt(key, defaultFor(key));
            }
        };
    }

    private int defaultFor(String key) {
        Config d = new Config();
        if (Config.K_THEME.equals(key)) return d.theme;
        if (Config.K_BORDER.equals(key)) return d.border;
        if (Config.K_TAP.equals(key)) return d.tap;
        if (Config.K_HOLD.equals(key)) return d.hold;
        if (Config.K_SWIPE.equals(key)) return d.swipe;
        return 0;
    }

    private IntConsumer setter(final String key) {
        return new IntConsumer() {
            @Override
            public void accept(int v) {
                prefs.edit().putInt(key, v).apply();
            }
        };
    }

    private void refreshAll() {
        cfg = Config.load(this);
        for (Runnable r : refreshers) r.run();
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private TextView section(String s) {
        TextView t = text(s, 19, TEXT, true);
        t.setPadding(0, px(22), 0, px(6));
        return t;
    }

    private TextView label(String s) {
        TextView t = text(s, 14, SUB, true);
        t.setPadding(0, px(8), 0, px(4));
        return t;
    }

    private TextView note(String s) {
        TextView t = text(s, 14, SUB, false);
        t.setLineSpacing(0, 1.15f);
        t.setPadding(0, 0, 0, px(6));
        return t;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(px(18));
        c.setBackground(g);
        c.setPadding(px(16), px(16), px(16), px(10));
        return c;
    }

    private LinearLayout.LayoutParams cardLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = px(10);
        return lp;
    }

    private TextView button(String s, boolean filled) {
        TextView b = text(s, 16, filled ? 0xFFFFFFFF : TEXT, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(px(16), px(13), px(16), px(13));
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(px(14));
        if (filled) {
            g.setColor(ACCENT);
        } else {
            g.setColor(CHIP);
            g.setStroke(px(1), ACCENT);
        }
        b.setBackground(g);
        b.setClickable(true);
        b.setFocusable(true);
        return b;
    }

    private LinearLayout.LayoutParams buttonLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = px(10);
        lp.bottomMargin = px(4);
        return lp;
    }

    private View chips(String[] labels, int[][] swatches, final IntSupplier get, final IntConsumer set) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, px(2), 0, px(2));
        final TextView[] views = new TextView[labels.length];
        for (int i = 0; i < labels.length; i++) {
            TextView t = text(labels[i], 14, TEXT, false);
            t.setPadding(px(14), px(9), px(14), px(9));
            t.setGravity(Gravity.CENTER_VERTICAL);
            if (swatches != null) {
                GradientDrawable sw = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, swatches[i]);
                sw.setShape(GradientDrawable.OVAL);
                sw.setBounds(0, 0, px(16), px(16));
                t.setCompoundDrawables(sw, null, null, null);
                t.setCompoundDrawablePadding(px(8));
            }
            final int idx = i;
            t.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    set.accept(idx);
                    refreshAll();
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = px(8);
            row.addView(t, lp);
            views[i] = t;
        }
        Runnable refresh = new Runnable() {
            @Override
            public void run() {
                int sel = get.getAsInt();
                for (int i = 0; i < views.length; i++) styleChip(views[i], i == sel);
            }
        };
        refreshers.add(refresh);
        refresh.run();
        hs.addView(row);
        return hs;
    }

    private void styleChip(TextView t, boolean selected) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(px(100));
        if (selected) {
            g.setColor(ACCENT);
        } else {
            g.setColor(CHIP);
            g.setStroke(px(1), CHIP_EDGE);
        }
        t.setBackground(g);
        t.setTypeface(Typeface.DEFAULT, selected ? Typeface.BOLD : Typeface.NORMAL);
    }

    private View slider(final String name, final String key, int min, int max, int value, final String unit) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, px(6), 0, 0);
        final TextView lab = text(name + ": " + value + unit, 14, SUB, false);
        box.addView(lab);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max);
        sb.setMin(min);
        sb.setProgress(value);
        sb.setProgressTintList(ColorStateList.valueOf(ACCENT));
        sb.setThumbTintList(ColorStateList.valueOf(ACCENT));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                lab.setText(name + ": " + v + unit);
                if (fromUser) prefs.edit().putInt(key, v).apply();
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        box.addView(sb, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return box;
    }

    private View toggle(String name, final String key, boolean value) {
        Switch sw = new Switch(this);
        sw.setText(name);
        sw.setTextColor(TEXT);
        sw.setTextSize(15);
        sw.setChecked(value);
        sw.setPadding(0, px(10), 0, px(10));
        sw.setThumbTintList(ColorStateList.valueOf(ACCENT));
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean on) {
                prefs.edit().putBoolean(key, on).apply();
            }
        });
        return sw;
    }
}
