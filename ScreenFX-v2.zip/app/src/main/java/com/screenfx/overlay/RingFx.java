package com.screenfx.overlay;

import android.graphics.Canvas;
import android.graphics.Paint;

/** Expanding shockwave ring. */
final class RingFx extends Fx {
    final float x, y, maxR, width;
    final int color;

    RingFx(float x, float y, float maxR, int color, float width, float life) {
        this.x = x;
        this.y = y;
        this.maxR = maxR;
        this.color = color;
        this.width = width;
        this.life = life;
    }

    @Override
    boolean update(FxView w, float dt) {
        return age < life;
    }

    @Override
    void draw(Canvas c, FxView w) {
        float t = age / life;
        Paint s = Gfx.stroke;
        s.setColor(color);
        s.setAlpha(Gfx.alpha(1 - t));
        s.setStrokeWidth(width * (1 - t) + w.dp);
        c.drawCircle(x, y, maxR * easeOut(t), s);
    }
}
