package com.screenfx.overlay;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

import java.util.Random;

/** Cartoon bomb with a burning fuse. */
final class BombFx extends Fx {
    static final int DROP = 0, THROW = 1, PLACE = 2;
    float x, y, vx, vy, rot, fuse;
    final float scale, floorY;
    final int mode;
    final ParticleFx sparks;
    private boolean landed;
    private final Path fusePath = new Path();
    private final float r, tipX, tipY;

    BombFx(FxView w, ParticleFx sparks, int mode, float x, float y, float vx, float vy, float floorY, float scale, float fuse) {
        this.sparks = sparks;
        this.mode = mode;
        this.x = x;
        this.y = y;
        this.vx = vx;
        this.vy = vy;
        this.floorY = floorY;
        this.scale = scale;
        this.fuse = fuse;
        this.life = 99;
        sparks.keepAlive = true;
        float dp = w.dp;
        r = 22 * dp;
        tipX = r * 0.7f;
        tipY = -r * 1.55f;
        fusePath.moveTo(0, -r * 1.12f);
        fusePath.quadTo(r * 0.3f, -r * 1.75f, tipX, tipY);
    }

    @Override
    boolean update(FxView w, float dt) {
        float dp = w.dp;
        float rad = r * scale;
        if (mode == DROP) {
            if (!landed) {
                vy += 2600 * dp * dt;
                y += vy * dt;
                if (y >= floorY) {
                    y = floorY;
                    if (vy > 500 * dp) {
                        vy = -vy * 0.3f;
                        w.shake(2 * dp);
                    } else {
                        landed = true;
                        vy = 0;
                    }
                }
            } else {
                fuse -= dt;
            }
        } else if (mode == THROW) {
            vy += 1800 * dp * dt;
            x += vx * dt;
            y += vy * dt;
            rot += vx * dt * 0.25f;
            int W = w.getWidth(), H = w.getHeight();
            if (x < rad) {
                x = rad;
                vx = -vx * 0.6f;
            }
            if (x > W - rad) {
                x = W - rad;
                vx = -vx * 0.6f;
            }
            if (y > H - rad) {
                y = H - rad;
                vy = -vy * 0.45f;
                vx *= 0.8f;
            }
            fuse -= dt;
        } else {
            fuse -= dt;
        }

        // fuse sparks, in screen coordinates
        float ps = popScale();
        float rr = (float) Math.toRadians(rot);
        float cr = cos(rr), sr = sin(rr);
        float wx = x + (tipX * cr - tipY * sr) * scale * ps, wy = y + (tipX * sr + tipY * cr) * scale * ps;
        Random rnd = w.rnd;
        for (int k = 0; k < 2; k++) {
            float a = rnd.nextFloat() * Gfx.TAU, sp = (60 + rnd.nextFloat() * 160) * dp;
            Particle p = sparks.add(Particle.SPARK, wx, wy, cos(a) * sp, sin(a) * sp - 60 * dp,
                    0.2f + rnd.nextFloat() * 0.2f, 1.6f * dp, 0xFFFFD54F);
            p.gravity = 500 * dp;
        }

        if (fuse <= 0) {
            Spawner.bigExplosion(w, x, y, scale);
            sparks.keepAlive = false;
            return false;
        }
        return true;
    }

    private float popScale() {
        if (mode != PLACE) return 1f;
        float t = Math.min(1, age / 0.22f);
        return t < 1 ? 1.15f * easeOut(t) : 1f;
    }

    @Override
    void draw(Canvas c, FxView w) {
        float dp = w.dp;
        float s = scale * popScale();
        c.save();
        c.translate(x, y);
        c.rotate(rot);
        c.scale(s, s);
        Paint f = Gfx.fill;
        Gfx.dot(c, 0, r * 0.15f, r * 1.6f, 0xFF000000, 70, false);
        f.setColor(0xFF1E1E24);
        c.drawCircle(0, 0, r, f);
        if (fuse < 0.5f) {
            float pulse = 0.5f + 0.5f * sin(age * 40);
            f.setColor(0xFFFF1744);
            f.setAlpha(Gfx.alpha(0.55f * pulse));
            c.drawCircle(0, 0, r, f);
        }
        Gfx.dot(c, -r * 0.35f, -r * 0.38f, r * 0.5f, 0xFFFFFFFF, 110, false);
        f.setColor(0xFF5A5A66);
        Gfx.tmp.set(-r * 0.32f, -r * 1.18f, r * 0.32f, -r * 0.8f);
        c.drawRoundRect(Gfx.tmp, 2 * dp, 2 * dp, f);
        Paint st = Gfx.stroke;
        st.setColor(0xFFC9B48C);
        st.setStrokeWidth(2.6f * dp);
        c.drawPath(fusePath, st);
        float fl = 0.7f + 0.3f * w.rnd.nextFloat();
        Gfx.dot(c, tipX, tipY, 14 * dp * fl, 0xFFFFB300, 255, true);
        Gfx.dot(c, tipX, tipY, 6 * dp, 0xFFFFFFFF, 255, true);
        c.restore();
    }
}
