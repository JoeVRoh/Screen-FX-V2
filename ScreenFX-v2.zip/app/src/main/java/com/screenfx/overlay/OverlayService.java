package com.screenfx.overlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.graphics.drawable.Icon;
import android.hardware.input.InputManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.Toast;

/**
 * Foreground service that owns the overlay windows:
 *  - a full-screen FxView (border + effects)
 *  - an optional floating bubble that toggles Play mode
 *
 * Pass-through mode: the overlay ignores touches so you can use your phone normally (border only).
 * Play mode: the overlay captures touches so tap / hold / swipe effects fire anywhere.
 */
public class OverlayService extends Service {
    public static final String ACTION_STOP = "com.screenfx.overlay.STOP";
    public static final String ACTION_TOGGLE = "com.screenfx.overlay.TOGGLE";
    private static final String CHANNEL = "overlay";
    private static final int NOTIF_ID = 1;

    static volatile boolean running = false;
    static volatile boolean playMode = false;

    private WindowManager wm;
    private FxView fx;
    private WindowManager.LayoutParams fxParams;
    private BubbleView bubble;
    private WindowManager.LayoutParams bubbleParams;
    private float passAlpha = 1f;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean replaying;
    private long lastHelperHint;

    private final SharedPreferences.OnSharedPreferenceChangeListener prefListener =
            new SharedPreferences.OnSharedPreferenceChangeListener() {
                @Override
                public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
                    if (Config.K_BUBBLE.equals(key)) updateBubble();
                    if (Config.K_PASS_TAPS.equals(key) && playMode) setPlayMode(true, false);
                    if (bubble != null) bubble.setPalette(Config.load(OverlayService.this).palette());
                }
            };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        startAsForeground();
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        running = true;
        playMode = false;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (Build.VERSION.SDK_INT >= 31) {
            // Android 12+ blocks touches passing through overlays more opaque than this.
            InputManager im = (InputManager) getSystemService(INPUT_SERVICE);
            passAlpha = Math.min(1f, im.getMaximumObscuringOpacityForTouch());
        }
        addFxWindow();
        updateBubble();
        Config.prefs(this).registerOnSharedPreferenceChangeListener(prefListener);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            if (ACTION_STOP.equals(intent.getAction())) {
                stopSelf();
            } else if (ACTION_TOGGLE.equals(intent.getAction()) && fx != null) {
                setPlayMode(!playMode, true);
            }
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        playMode = false;
        Config.prefs(this).unregisterOnSharedPreferenceChangeListener(prefListener);
        safeRemove(bubble);
        safeRemove(fx);
        bubble = null;
        fx = null;
        super.onDestroy();
    }

    private void safeRemove(View v) {
        if (v == null || wm == null) return;
        try {
            wm.removeView(v);
        } catch (Exception ignored) {
        }
    }

    // ---------------- windows ----------------

    private WindowManager.LayoutParams baseParams(int w, int h) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        return lp;
    }

    private void addFxWindow() {
        fx = new FxView(this);
        fx.setTouchEnabled(false);
        fxParams = baseParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        fxParams.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        fxParams.alpha = passAlpha;
        wm.addView(fx, fxParams);
    }

    private void updateBubble() {
        if (wm == null) return;
        boolean want = Config.load(this).bubble;
        if (want && bubble == null) {
            DisplayMetrics dm = getResources().getDisplayMetrics();
            int size = (int) (54 * dm.density);
            bubble = new BubbleView(this);
            bubble.setPalette(Config.load(this).palette());
            bubble.setActive(playMode);
            bubbleParams = baseParams(size, size);
            bubbleParams.x = dm.widthPixels - size - (int) (10 * dm.density);
            bubbleParams.y = (int) (dm.heightPixels * 0.35f);
            bubble.setOnTouchListener(new BubbleTouch());
            wm.addView(bubble, bubbleParams);
        } else if (!want && bubble != null) {
            safeRemove(bubble);
            bubble = null;
        }
    }

    void setPlayMode(boolean on, boolean announce) {
        if (fx == null) return;
        playMode = on;
        boolean pass = on && Config.load(this).passTaps;
        fx.setTouchEnabled(on);
        fx.setGestureSink(pass ? new FxView.GestureSink() {
            @Override
            public void onGesture(float[] xs, float[] ys, int n, long durationMs) {
                replayToApps(xs, ys, n, durationMs);
            }
        } : null);
        if (on) {
            fxParams.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            // replayed touches must pass through this window, which Android only allows below this opacity
            fxParams.alpha = pass ? passAlpha : 1f;
        } else {
            fxParams.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
            fxParams.alpha = passAlpha;
        }
        try {
            wm.updateViewLayout(fx, fxParams);
        } catch (Exception ignored) {
        }
        if (bubble != null) bubble.setActive(on);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(NOTIF_ID, buildNotification());
        if (announce) {
            Toast.makeText(this, on ? "Play mode ON: tap, hold or swipe anywhere"
                    : "Play mode OFF: your phone works normally", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * "Taps still work" mode: the overlay has already drawn the effect; now make it untouchable for a moment
     * and have the tap helper replay the same gesture to the app underneath.
     */
    private void replayToApps(final float[] xs, final float[] ys, final int n, final long durationMs) {
        final TapHelperService helper = TapHelperService.instance;
        if (helper == null) {
            long now = System.currentTimeMillis();
            if (now - lastHelperHint > 8000) {
                lastHelperHint = now;
                Toast.makeText(this, "Turn on the ScreenFX tap helper (in ScreenFX settings) so taps reach your apps",
                        Toast.LENGTH_LONG).show();
            }
            return;
        }
        if (replaying || fx == null) return;
        replaying = true;
        fx.setTouchEnabled(false);
        fxParams.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        try {
            wm.updateViewLayout(fx, fxParams);
        } catch (Exception ignored) {
        }
        final Runnable restore = new Runnable() {
            @Override
            public void run() {
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        replaying = false;
                        if (fx == null || !playMode) return;
                        fxParams.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
                        try {
                            wm.updateViewLayout(fx, fxParams);
                        } catch (Exception ignored) {
                        }
                        fx.setTouchEnabled(true);
                    }
                }, 40);
            }
        };
        // give the window manager a moment to make the overlay untouchable before replaying
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!helper.replay(xs, ys, n, durationMs, restore)) restore.run();
            }
        }, 45);
    }

    private void openSettings() {
        if (playMode) setPlayMode(false, false);
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        try {
            startActivity(i);
        } catch (Exception ignored) {
        }
    }

    /** Drag the bubble around; tap toggles Play mode; long-press opens settings. */
    private final class BubbleTouch implements View.OnTouchListener, Runnable {
        private float sx, sy;
        private int px, py;
        private boolean moved, longFired;
        private final float slop = ViewConfiguration.get(OverlayService.this).getScaledTouchSlop();

        @Override
        public void run() {
            longFired = true;
            if (bubble != null) bubble.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
            openSettings();
        }

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    sx = e.getRawX();
                    sy = e.getRawY();
                    px = bubbleParams.x;
                    py = bubbleParams.y;
                    moved = false;
                    longFired = false;
                    v.postDelayed(this, 650);
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - sx, dy = e.getRawY() - sy;
                    if (!moved && Math.hypot(dx, dy) > slop) {
                        moved = true;
                        v.removeCallbacks(this);
                    }
                    if (moved && bubble != null) {
                        bubbleParams.x = px + (int) dx;
                        bubbleParams.y = py + (int) dy;
                        try {
                            wm.updateViewLayout(bubble, bubbleParams);
                        } catch (Exception ignored) {
                        }
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                    v.removeCallbacks(this);
                    if (!moved && !longFired) {
                        v.performClick();
                        setPlayMode(!playMode, true);
                    }
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    v.removeCallbacks(this);
                    return true;
                default:
                    return false;
            }
        }
    }

    // ---------------- notification ----------------

    private void startAsForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Overlay running", NotificationManager.IMPORTANCE_LOW);
        ch.setDescription("Shown while ScreenFX is drawing over the screen");
        ch.setShowBadge(false);
        nm.createNotificationChannel(ch);
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private Notification buildNotification() {
        int pf = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), pf);
        PendingIntent toggle = PendingIntent.getService(this, 1,
                new Intent(this, OverlayService.class).setAction(ACTION_TOGGLE), pf);
        PendingIntent stop = PendingIntent.getService(this, 2,
                new Intent(this, OverlayService.class).setAction(ACTION_STOP), pf);
        Icon icon = Icon.createWithResource(this, R.drawable.ic_stat);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(playMode ? "ScreenFX: Play mode" : "ScreenFX overlay is on")
                .setContentText(playMode ? "Touches create effects. Tap 'Normal use' to use your phone."
                        : "Border is showing. Tap 'Play mode' for touch effects.")
                .setContentIntent(open)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(icon, playMode ? "Normal use" : "Play mode", toggle).build())
                .addAction(new Notification.Action.Builder(icon, "Stop", stop).build())
                .build();
    }
}
