package com.screenfx.overlay;

import android.graphics.Canvas;
import android.graphics.Paint;

import java.util.ArrayList;

/** A group of simple particles. */
class ParticleFx extends Fx {
    final ArrayList<Particle> ps = new ArrayList<>();
    boolean keepAlive;

    Particle add(int kind, float x, float y, float vx, float vy, float life, float size, int color) {
        Particle p = new Particle();
        p.kind = kind;
        p.x = x;
        p.y = y;
        p.vx = vx;
        p.vy = vy;
        p.life = Math.max(0.01f, life);
        p.size = size;
        p.color = color;
        p.color2 = color;
        ps.add(p);
        return p;
    }

    @Override
    boolean update(FxView w, float dt) {
        for (int i = ps.size() - 1; i >= 0; i--) {
            Particle p = ps.get(i);
            p.age += dt;
            if (p.age >= p.life) {
                int last = ps.size() - 1;
                ps.set(i, ps.get(last));
                ps.remove(last);
                continue;
            }
            p.vy += p.gravity * dt;
            float d = 1f / (1f + p.drag * dt);
            p.vx *= d;
            p.vy *= d;
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.size = Math.max(0, p.size + p.grow * dt);
            p.rot += p.vrot * dt;
        }
        return keepAlive || !ps.isEmpty();
    }

    @Override
    void draw(Canvas c, FxView w) {
        for (int i = 0, n = ps.size(); i < n; i++) drawParticle(c, ps.get(i));
    }

    static void drawParticle(Canvas c, Particle p) {
        float t = p.age / p.life;
        float fade = (1 - t) * p.baseAlpha;
        switch (p.kind) {
            case Particle.DOT:
                Gfx.dot(c, p.x, p.y, p.size, p.color, Gfx.alpha(fade), p.add);
                break;
            case Particle.FLAME: {
                int col = Gfx.lerp(p.color, p.color2, Math.min(1, t * 1.6f));
                Gfx.dot(c, p.x, p.y, p.size, col, Gfx.alpha(fade), true);
                break;
            }
            case Particle.SMOKE: {
                float in = Math.min(1, t * 6);
                Gfx.dot(c, p.x, p.y, p.size, p.color, Gfx.alpha(fade * in), false);
                break;
            }
            case Particle.CIRCLE: {
                Paint f = Gfx.fill;
                f.setColor(p.color);
                f.setAlpha(Gfx.alpha(fade));
                c.drawCircle(p.x, p.y, p.size, f);
                break;
            }
            case Particle.CONFETTI: {
                Paint f = Gfx.fill;
                f.setColor(p.color);
                f.setAlpha(Gfx.alpha(Math.min(1, fade * 2)));
                float wdt = p.size * (0.25f + 0.75f * Math.abs(Fx.sin(p.age * 9 + p.phase)));
                c.save();
                c.translate(p.x, p.y);
                c.rotate(p.rot);
                c.drawRect(-wdt / 2, -p.size * 0.32f, wdt / 2, p.size * 0.32f, f);
                c.restore();
                break;
            }
            case Particle.SPARK: {
                Paint s = Gfx.stroke;
                s.setColor(p.color);
                s.setAlpha(Gfx.alpha(fade));
                s.setStrokeWidth(Math.max(1f, p.size));
                c.drawLine(p.x, p.y, p.x - p.vx * 0.03f, p.y - p.vy * 0.03f, s);
                break;
            }
            case Particle.STAR: {
                float tw = 0.55f + 0.45f * Fx.sin(p.age * 16 + p.phase);
                float a = fade * tw;
                Gfx.dot(c, p.x, p.y, p.size * 1.3f, p.color, Gfx.alpha(a * 0.5f), true);
                Paint f = Gfx.fill;
                f.setColor(Gfx.lerp(p.color, 0xFFFFFFFF, 0.5f));
                f.setAlpha(Gfx.alpha(a));
                c.save();
                c.translate(p.x, p.y);
                c.rotate(p.rot);
                c.scale(p.size, p.size);
                c.drawPath(Gfx.star, f);
                c.restore();
                break;
            }
            case Particle.SHARD: {
                Paint f = Gfx.fill;
                f.setColor(p.color);
                f.setAlpha(Gfx.alpha(fade * (p.color >>> 24) / 255f));
                c.save();
                c.translate(p.x, p.y);
                c.rotate(p.rot);
                c.scale(p.size, p.size);
                c.drawPath(Gfx.shard, f);
                c.restore();
                break;
            }
            case Particle.HEART: {
                float pop = Math.min(1, p.age / 0.15f);
                Paint f = Gfx.fill;
                f.setColor(p.color);
                f.setAlpha(Gfx.alpha(Math.min(1, fade * 1.6f)));
                float sz = p.size * (0.5f + 0.5f * pop) * (1 + 0.06f * Fx.sin(p.age * 10 + p.phase));
                c.save();
                c.translate(p.x + 6 * Fx.sin(p.age * 3 + p.phase) * p.size / 10, p.y);
                c.rotate(p.rot);
                c.scale(sz, sz);
                c.drawPath(Gfx.heart, f);
                c.restore();
                break;
            }
            default:
                break;
        }
    }
}
