# No special rules needed: the app has no reflection or third-party libraries.
