#!/usr/bin/env python3
"""Synthesizes every ScreenFX sound effect from scratch (no samples, no licensing worries).

Usage:  python3 tools/make_sounds.py
Writes OGG files into app/src/main/res/raw/ (needs numpy, scipy and ffmpeg).
"""
import os
import subprocess
import tempfile

import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt

SR = 22050
OUT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "res", "raw")
rng = np.random.default_rng(7)


def t_(d):
    return np.arange(int(d * SR)) / SR


def noise(n):
    return rng.standard_normal(n)


def lp(x, f, order=4):
    return sosfilt(butter(order, f, "low", fs=SR, output="sos"), x)


def hp(x, f, order=4):
    return sosfilt(butter(order, f, "high", fs=SR, output="sos"), x)


def bp(x, lo, hi, order=3):
    return sosfilt(butter(order, [lo, hi], "band", fs=SR, output="sos"), x)


def sweep(f):
    """Sine with a time-varying frequency array."""
    return np.sin(2 * np.pi * np.cumsum(f) / SR)


def env(t, attack=0.003, tau=0.1):
    return (1 - np.exp(-t / max(attack, 1e-4))) * np.exp(-t / tau)


def smooth_noise(n, cutoff):
    s = lp(noise(n), cutoff, 2)
    return s / (np.abs(s).max() + 1e-9)


def fade(x, ms_in=2, ms_out=20):
    a, b = int(ms_in * SR / 1000), int(ms_out * SR / 1000)
    if a:
        x[:a] *= np.linspace(0, 1, a)
    if b:
        x[-b:] *= np.linspace(1, 0, b)
    return x


def place(buf, sig, at):
    i = int(at * SR)
    end = min(len(buf), i + len(sig))
    buf[i:end] += sig[: end - i]


def bell(f, d, tau=0.35):
    t = t_(d)
    return (np.sin(2 * np.pi * f * t) * np.exp(-t / tau)
            + 0.35 * np.sin(2 * np.pi * f * 2.76 * t) * np.exp(-t / (tau * 0.4))
            + 0.15 * np.sin(2 * np.pi * f * 5.4 * t) * np.exp(-t / (tau * 0.2)))


# ---------------- sounds ----------------

def pop():
    t = t_(0.16)
    f = 250 + 650 * np.exp(-t / 0.02)
    return sweep(f) * env(t, 0.001, 0.035) + 0.5 * hp(noise(len(t)), 2000) * np.exp(-t / 0.004)


def whoosh():
    d = 0.7
    t = t_(d)
    n = noise(len(t))
    low = bp(n, 250, 1200) * np.sin(np.pi * np.clip(t / 0.55, 0, 1)) ** 2
    high = bp(n, 1200, 4000) * np.sin(np.pi * np.clip((t - 0.1) / 0.6, 0, 1)) ** 2
    return low + 0.6 * high


def boom(d=1.4, tau=0.35, big=False):
    # Phone speakers can't play deep bass, so the energy sits in 80-2500 Hz.
    t = t_(d)
    n = len(t)
    body = bp(noise(n), 70, 1000) * env(t, 0.004, tau)
    crunch = bp(noise(n), 300, 2500) * env(t, 0.002, tau * 0.3)
    thump = sweep(55 + 60 * np.exp(-t / 0.08)) * env(t, 0.002, 0.18)
    crack = hp(noise(n), 1500) * np.exp(-t / 0.02)
    x = 1.4 * body + 0.6 * crunch + 0.9 * thump + 0.4 * crack
    if big:
        rumble = bp(noise(n), 50, 400) * (0.6 + 0.4 * smooth_noise(n, 5)) * np.exp(-t / 1.0)
        x += 1.6 * rumble
    return np.tanh(2.2 * x / (np.abs(x).max() + 1e-9))


def shot():
    d = 0.75
    t = t_(d)
    n = len(t)
    x = 1.0 * hp(noise(n), 1500) * np.exp(-t / 0.012)
    x += 0.7 * bp(noise(n), 200, 2200) * env(t, 0.001, 0.06)
    x += 0.8 * np.sin(2 * np.pi * 110 * t) * env(t, 0.001, 0.05)
    # glass: tiny high pings scattered after the crack
    glass = np.zeros(n)
    for _ in range(16):
        t0 = rng.uniform(0.02, 0.45)
        f = rng.uniform(2800, 7500)
        tt = t_(0.12)
        place(glass, rng.uniform(0.1, 0.3) * np.sin(2 * np.pi * f * tt) * np.exp(-tt / 0.025), t0)
    glass += 0.08 * hp(noise(n), 5000) * np.exp(-np.maximum(t - 0.02, 0) / 0.15) * (t > 0.02)
    return np.tanh(1.5 * x) + glass


def chime():
    buf = np.zeros(int(1.3 * SR))
    notes = [1046.5, 1318.5, 1568.0, 1760.0, 2093.0]
    for i in range(4):
        place(buf, bell(rng.choice(notes), 1.0, 0.3) * (1 - i * 0.12), i * 0.06)
    return buf


def drop():
    t = t_(0.35)
    f = np.minimum(350 * np.exp(t * 16), 1500)
    x = sweep(f) * env(t, 0.002, 0.06)
    tt = t_(0.2)
    x2 = sweep(np.minimum(500 * np.exp(tt * 18), 1800)) * env(tt, 0.002, 0.04) * 0.4
    buf = np.zeros(len(t))
    place(buf, x, 0)
    place(buf, x2, 0.09)
    return buf


def puff():
    t = t_(0.55)
    return lp(noise(len(t)), 900) * env(t, 0.03, 0.15)


def thunder():
    d = 3.0
    t = t_(d)
    n = len(t)
    x = 0.6 * hp(noise(n), 1200) * np.exp(-t / 0.03)
    x += 0.9 * bp(noise(n), 100, 1500) * env(t, 0.005, 0.35)
    x += 2.5 * bp(noise(n), 50, 600) * (0.4 + 0.6 * smooth_noise(n, 3)) * env(t, 0.08, 1.2)
    return np.tanh(1.8 * x / (np.abs(x).max() + 1e-9))


def fuse():
    d = 1.3
    t = t_(d)
    n = len(t)
    hiss = hp(noise(n), 2500) * 0.35
    clicks = (rng.random(n) < 0.004) * rng.uniform(0.5, 1.0, n)
    crackle = hp(lp(clicks, 6000, 2), 1500) * 6
    x = hiss + crackle
    return fade(x, 40, 120)


def laser():
    t = t_(0.32)
    f = 250 + 1700 * np.exp(-t * 9) + 30 * np.sin(2 * np.pi * 40 * t)
    return np.tanh(3 * sweep(f)) * env(t, 0.002, 0.12) * 0.8


def splat():
    t = t_(0.4)
    n = len(t)
    x = lp(noise(n), 1400) * env(t, 0.001, 0.05)
    x += 0.8 * np.sin(2 * np.pi * 90 * t) * env(t, 0.001, 0.04)
    for _ in range(4):
        tt = t_(0.06)
        place(x, 0.25 * sweep(rng.uniform(250, 450) * np.exp(tt * 12)) * env(tt, 0.002, 0.02), rng.uniform(0.04, 0.2))
    return x


def bling():
    buf = np.zeros(int(0.9 * SR))
    place(buf, bell(1318.5, 0.8, 0.25), 0)
    place(buf, bell(1975.5, 0.8, 0.3), 0.08)
    return buf


def whistle():
    d = 0.9
    t = t_(d)
    f = 700 + 1500 * (t / d) ** 1.3 + 25 * np.sin(2 * np.pi * 18 * t)
    x = sweep(f) + 0.15 * bp(noise(len(t)), 1500, 5000)
    return fade(x * 0.6, 60, 60)


def bang():
    t = t_(1.1)
    n = len(t)
    x = 1.0 * hp(noise(n), 1200) * np.exp(-t / 0.015)
    x += 1.2 * lp(noise(n), 300) * env(t, 0.002, 0.2)
    x += 0.9 * np.sin(2 * np.pi * 70 * t) * env(t, 0.002, 0.12)
    return np.tanh(1.8 * x / (np.abs(x).max() + 1e-9))


def crackle():
    d = 1.0
    buf = np.zeros(int(d * SR))
    for _ in range(45):
        t0 = rng.uniform(0, d * 0.85) ** 1.2
        tt = t_(0.004)
        place(buf, rng.uniform(0.3, 1.0) * hp(noise(len(tt)), 2500) * np.exp(-tt / 0.0012), t0)
    return buf


def fart(dur, f0, f1, flutter=24.0, wet=0.2, wobble=0.15, stutter=0.0, tail_squeak=False, bright=900):
    t = t_(dur)
    n = len(t)
    f = f0 + (f1 - f0) * (t / dur) ** 0.7
    f += f0 * wobble * np.sin(2 * np.pi * 3.1 * t + rng.uniform(0, 6))
    f += f0 * 0.12 * smooth_noise(n, 25)
    if tail_squeak:
        f += 90 * np.clip((t - dur * 0.85) / (dur * 0.15), 0, 1) ** 2
    ph = np.cumsum(f) / SR
    saw = 2 * (ph % 1.0) - 1
    sq = np.sign(np.sin(2 * np.pi * ph)) * np.abs(np.sin(2 * np.pi * ph)) ** 0.4
    src = 0.55 * saw + 0.45 * sq
    body = lp(src, bright) + 0.6 * bp(src, 180, 520)
    rate = flutter * (1 + 0.25 * smooth_noise(n, 3))
    am = 0.55 + 0.45 * np.sin(2 * np.pi * np.cumsum(rate) / SR)
    if stutter:
        gate = (np.sin(2 * np.pi * stutter * t) > -0.2).astype(float)
        am *= 0.12 + 0.88 * lp(gate, 50, 2)
    bursts = lp(np.abs(noise(n)) ** 3, 40, 2)
    wetsig = bp(noise(n), 300, 2500) * bursts / (bursts.max() + 1e-9)
    e = (1 - np.exp(-t / 0.015))
    tail = np.clip((dur - t) / (dur * 0.25), 0, 1) ** 0.7
    x = (body * am + wet * wetsig) * e * tail
    x = np.tanh(1.8 * x / (np.abs(x).max() + 1e-9))
    return lp(x, 1600)


def fart_pfft():
    t = t_(0.32)
    n = len(t)
    x = bp(noise(n), 400, 2200) * env(t, 0.004, 0.08)
    x += 0.3 * lp(2 * ((np.cumsum(np.full(n, 150.0)) / SR) % 1) - 1, 600) * env(t, 0.004, 0.06)
    return x


SOUNDS = {
    "pop": pop,
    "whoosh": whoosh,
    "boom": lambda: boom(),
    "big_boom": lambda: boom(2.6, 0.6, big=True),
    "shot": shot,
    "chime": chime,
    "drop": drop,
    "puff": puff,
    "thunder": thunder,
    "fuse": fuse,
    "laser": laser,
    "splat": splat,
    "bling": bling,
    "whistle": whistle,
    "bang": bang,
    "crackle": crackle,
    "fart_short": lambda: fart(0.45, 115, 88, flutter=28, wet=0.15),
    "fart_classic": lambda: fart(0.95, 95, 70, flutter=22, wet=0.2, wobble=0.2),
    "fart_squeak": lambda: fart(0.55, 230, 330, flutter=34, wet=0.05, bright=2200),
    "fart_wet": lambda: fart(0.85, 82, 60, flutter=18, wet=0.75),
    "fart_pfft": fart_pfft,
    "fart_long": lambda: fart(2.3, 102, 66, flutter=20, wet=0.25, wobble=0.3, tail_squeak=True),
    "fart_ripple": lambda: fart(1.6, 120, 80, flutter=26, wet=0.15, stutter=9.5),
}


def write(name, x):
    x = np.asarray(x, dtype=np.float64)
    x = x / (np.abs(x).max() + 1e-9) * 0.89
    x = fade(x, 1, 15)
    pcm = (x * 32767).astype(np.int16)
    os.makedirs(OUT, exist_ok=True)
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
        wavfile.write(tmp.name, SR, pcm)
    dst = os.path.join(OUT, name + ".ogg")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", tmp.name, "-c:a", "libvorbis", "-q:a", "4", dst], check=True)
    os.unlink(tmp.name)
    rms = float(np.sqrt(np.mean(x ** 2)))
    print(f"{name:14s} {len(x) / SR:4.2f}s  rms={rms:.3f}  {os.path.getsize(dst) // 1024} KB")


if __name__ == "__main__":
    for k, fn in SOUNDS.items():
        write(k, fn())
